document.addEventListener("DOMContentLoaded", function () {
    const bug = document.getElementById("bug");

    function moveBug() {
        const gameArea = document.getElementById("game-area");
        const maxX = gameArea.clientWidth - bug.clientWidth;
        const maxY = gameArea.clientHeight - bug.clientHeight;

        const newX = Math.floor(Math.random() * maxX);
        const newY = Math.floor(Math.random() * maxY);

        bug.style.left = `${newX}px`;
        bug.style.top = `${newY}px`;
    }

    // This makes the bug move when hovered
    bug.addEventListener("mouseenter", moveBug);

    // When clicked, show win message
    bug.addEventListener("click", function () {
        alert("You caught the bug!");
    });

    // Debugging Instructions for DevTools
    console.log("%cRemove the event listener to win!", "color: cyan; font-size: 16px; background: black;");
    console.log("To disable the bug’s movement, type this in the console:");
    console.log("%cbug.removeEventListener('mouseenter', moveBug);", "color: lime; font-weight: bold;");

    // Expose variables globally so the user can modify them in DevTools
    window.bug = bug;
    window.moveBug = moveBug;
});
