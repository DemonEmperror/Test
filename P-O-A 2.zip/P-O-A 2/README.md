# Plan of Action (POA) System

A Java-based web application for managing employee plans, work logs, and approvals with role-based dashboards.

## Project Structure

```
P-O-A/
├── src/
│   └── main/
│       ├── java/
│       │   └── com/
│       │       └── poa/
│       │           ├── controller/
│       │           │   ├── AdminController.java
│       │           │   ├── AuthController.java
│       │           │   ├── DashboardController.java
│       │           │   ├── PlanController.java
│       │           │   ├── ReportController.java
│       │           │   └── WorkLogController.java
│       │           ├── dao/
│       │           │   ├── PlanDAO.java
│       │           │   ├── UserDAO.java
│       │           │   └── WorkLogDAO.java
│       │           └── model/
│       │               ├── Approval.java
│       │               ├── Plan.java
│       │               ├── User.java
│       │               └── WorkLog.java
│       └── webapp/
│           ├── WEB-INF/
│           │   ├── lib/
│           │   │   ├── commons-codec-1.15.jar
│           │   │   ├── commons-dbcp2-2.9.0.jar
│           │   │   ├── commons-io-2.11.0.jar
│           │   │   ├── commons-lang3-3.12.0.jar
│           │   │   ├── commons-pool2-2.11.1.jar
│           │   │   ├── gson-2.9.0.jar
│           │   │   ├── javax.servlet-api-4.0.1.jar
│           │   │   ├── json-20220320.jar
│           │   │   ├── jstl-1.2.jar
│           │   │   ├── log4j-api-2.17.2.jar
│           │   │   ├── log4j-core-2.17.2.jar
│           │   │   └── mysql-connector-java-8.0.28.jar
│           │   ├── views/
│           │   │   ├── auth/
│           │   │   │   └── login.jsp
│           │   │   ├── common/
│           │   │   │   └── layout.jsp
│           │   │   ├── dashboard/
│           │   │   │   ├── admin_dashboard.jsp
│           │   │   │   ├── employee_dashboard.jsp
│           │   │   │   ├── index.jsp
│           │   │   │   ├── manager_dashboard.jsp
│           │   │   │   └── team_lead_dashboard.jsp
│           │   │   └── plans/
│           │   │       ├── create.jsp
│           │   │       ├── create_content.jsp
│           │   │       ├── list.jsp
│           │   │       ├── list_content.jsp
│           │   │       ├── view.jsp
│           │   │       └── view_content.jsp
│           │   └── web.xml
│           └── index.jsp
└── download_dependencies.sh
```

## Dependencies

The following JAR files have been downloaded and are available in the `src/main/webapp/WEB-INF/lib` directory:

1. **javax.servlet-api-4.0.1.jar** - Java Servlet API
2. **jstl-1.2.jar** - JavaServer Pages Standard Tag Library
3. **mysql-connector-java-8.0.28.jar** - MySQL JDBC Driver
4. **commons-dbcp2-2.9.0.jar** - Apache Commons DBCP for connection pooling
5. **commons-pool2-2.11.1.jar** - Apache Commons Pool (required by DBCP)
6. **commons-io-2.11.0.jar** - Apache Commons IO for file operations
7. **commons-lang3-3.12.0.jar** - Apache Commons Lang for utility functions
8. **json-20220320.jar** - JSON library
9. **gson-2.9.0.jar** - Google's JSON library
10. **log4j-api-2.17.2.jar** - Log4j API for logging
11. **log4j-core-2.17.2.jar** - Log4j Core implementation
12. **commons-codec-1.15.jar** - Apache Commons Codec for encryption

## Setup Instructions

### Database Setup

1. Create a MySQL database named `poa_db`
2. Run the SQL scripts to create the necessary tables (to be created)

### Tomcat Setup

1. Download and install Apache Tomcat 9.x
2. Configure Tomcat to run on port 8080 (or your preferred port)
3. Deploy the application by copying the project directory to Tomcat's webapps directory or creating a WAR file

### Running the Application

1. Start Tomcat
2. Access the application at `http://localhost:8080/P-O-A`

## User Roles

1. **Employee**: Create and manage plans, log work
2. **Team Lead**: Review and approve plans, view team performance
3. **Manager**: Final approval of plans, view department performance
4. **Admin**: Manage users, system settings, view system health

## Features

1. **User Authentication**: Secure login system
2. **Role-based Dashboards**: Different views for different user roles
3. **Plan Management**: Create, edit, view, and delete plans
4. **Work Log Management**: Track actual work done against plans
5. **Approval Workflow**: Multi-level approval process
6. **Reporting**: Generate reports on plans and work logs
7. **Admin Panel**: Manage users and system settings

## Development Notes

- The application follows the MVC architecture
- JSP is used for the view layer
- Servlets are used for the controller layer
- DAO pattern is used for data access
- Password hashing is implemented using SHA-256
- CSRF protection is implemented for form submissions
