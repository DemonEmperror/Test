#!/bin/bash

# Create lib directory if it doesn't exist
mkdir -p src/main/webapp/WEB-INF/lib

# Change to the lib directory
cd src/main/webapp/WEB-INF/lib

# Download Servlet API
echo "Downloading Servlet API..."
curl -L -O https://repo1.maven.org/maven2/javax/servlet/javax.servlet-api/4.0.1/javax.servlet-api-4.0.1.jar

# Download JSTL
echo "Downloading JSTL..."
curl -L -O https://repo1.maven.org/maven2/javax/servlet/jstl/1.2/jstl-1.2.jar

# Download MySQL Connector
echo "Downloading MySQL Connector..."
curl -L -O https://repo1.maven.org/maven2/mysql/mysql-connector-java/8.0.28/mysql-connector-java-8.0.28.jar

# Download Commons DBCP for connection pooling
echo "Downloading Commons DBCP..."
curl -L -O https://repo1.maven.org/maven2/org/apache/commons/commons-dbcp2/2.9.0/commons-dbcp2-2.9.0.jar
curl -L -O https://repo1.maven.org/maven2/org/apache/commons/commons-pool2/2.11.1/commons-pool2-2.11.1.jar

# Download Commons IO for file operations
echo "Downloading Commons IO..."
curl -L -O https://repo1.maven.org/maven2/commons-io/commons-io/2.11.0/commons-io-2.11.0.jar

# Download Commons Lang for utility functions
echo "Downloading Commons Lang..."
curl -L -O https://repo1.maven.org/maven2/org/apache/commons/commons-lang3/3.12.0/commons-lang3-3.12.0.jar

# Download JSON libraries
echo "Downloading JSON libraries..."
curl -L -O https://repo1.maven.org/maven2/org/json/json/20220320/json-20220320.jar
curl -L -O https://repo1.maven.org/maven2/com/google/code/gson/gson/2.9.0/gson-2.9.0.jar

# Download Log4j for logging
echo "Downloading Log4j..."
curl -L -O https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-api/2.17.2/log4j-api-2.17.2.jar
curl -L -O https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-core/2.17.2/log4j-core-2.17.2.jar

# Download Commons Codec for encryption
echo "Downloading Commons Codec..."
curl -L -O https://repo1.maven.org/maven2/commons-codec/commons-codec/1.15/commons-codec-1.15.jar

echo "All dependencies downloaded successfully!"
