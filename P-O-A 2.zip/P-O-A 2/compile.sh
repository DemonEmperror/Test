#!/bin/bash

# Set project directories
PROJECT_DIR=$(pwd)
SRC_DIR="$PROJECT_DIR/src/main/java"
WEB_DIR="$PROJECT_DIR/src/main/webapp"
BUILD_DIR="$PROJECT_DIR/build"
LIB_DIR="$WEB_DIR/WEB-INF/lib"
CLASSES_DIR="$BUILD_DIR/WEB-INF/classes"
WAR_FILE="$PROJECT_DIR/POA.war"

# Create build directories if they don't exist
mkdir -p "$CLASSES_DIR"
mkdir -p "$BUILD_DIR/WEB-INF/lib"

# Clean up old class files
rm -rf "$CLASSES_DIR"/*

# Set up classpath with all JAR files
CLASSPATH="$WEB_DIR/WEB-INF/classes"
for jar in "$LIB_DIR"/*.jar; do
    CLASSPATH="$CLASSPATH:$jar"
done

echo "Compiling Java files..."
# Compile all Java files
find "$SRC_DIR" -name "*.java" -print | xargs javac -d "$CLASSES_DIR" -cp "$CLASSPATH" -Xlint:none || true

# Copy web resources to build directory
cp -r "$WEB_DIR"/* "$BUILD_DIR"

# Copy JAR files to WEB-INF/lib
mkdir -p "$BUILD_DIR/WEB-INF/lib"
cp "$LIB_DIR"/*.jar "$BUILD_DIR/WEB-INF/lib"

# Create WAR file
cd "$BUILD_DIR"
jar -cvf "$WAR_FILE" *

echo "Compilation and WAR file creation completed successfully!"
