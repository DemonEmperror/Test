-- Create the database
CREATE DATABASE IF NOT EXISTS poa_db;
USE poa_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('Manager', 'Team Lead', 'SDE', 'JSDE', 'Intern', 'Admin') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Plans table
CREATE TABLE IF NOT EXISTS plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    date DATE NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected', 'Needs Rework') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Plan_deliverables table
CREATE TABLE IF NOT EXISTS plan_deliverables (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plan_id INT NOT NULL,
    description TEXT NOT NULL,
    estimated_time FLOAT NOT NULL,
    actual_time FLOAT DEFAULT 0,
    overflow_hours FLOAT DEFAULT 0,
    rework BOOLEAN DEFAULT FALSE,
    achieved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE CASCADE
);

-- Work_logs table
CREATE TABLE IF NOT EXISTS work_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    date DATE NOT NULL,
    plan_id INT,
    actual_time FLOAT NOT NULL,
    unplanned_work TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE SET NULL
);

-- Approvals table
CREATE TABLE IF NOT EXISTS approvals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plan_id INT NOT NULL,
    approved_by INT NOT NULL,
    role ENUM('Team Lead', 'Manager') NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected', 'Needs Rework') NOT NULL,
    comments TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert sample data
-- Sample Users
INSERT INTO users (name, email, password_hash, role) VALUES
('John Admin', 'admin@poa.com', 'admin123', 'Admin'),
('Sarah Manager', 'manager@poa.com', 'manager123', 'Manager'),
('Mike Lead', 'lead@poa.com', 'lead123', 'Team Lead'),
('Alice Dev', 'sde@poa.com', 'sde123', 'SDE'),
('Bob Junior', 'jsde@poa.com', 'jsde123', 'JSDE'),
('Charlie Intern', 'intern@poa.com', 'intern123', 'Intern');

-- Sample Plans
INSERT INTO plans (user_id, date, status) VALUES
(4, CURDATE() - INTERVAL 7 DAY, 'Approved'),
(4, CURDATE() - INTERVAL 1 DAY, 'Pending'),
(5, CURDATE() - INTERVAL 3 DAY, 'Needs Rework'),
(6, CURDATE() - INTERVAL 2 DAY, 'Rejected');

-- Sample Plan Deliverables
INSERT INTO plan_deliverables (plan_id, description, estimated_time, actual_time, overflow_hours, rework, achieved) VALUES
(1, 'Implement login functionality', 4.0, 4.5, 0.5, FALSE, TRUE),
(1, 'Create database schema', 2.0, 1.5, 0.0, FALSE, TRUE),
(2, 'Design dashboard UI', 3.0, 0.0, 0.0, FALSE, FALSE),
(2, 'Implement user profile page', 5.0, 0.0, 0.0, FALSE, FALSE),
(3, 'Fix bugs in reporting module', 6.0, 7.0, 1.0, TRUE, FALSE),
(4, 'Create documentation', 4.0, 0.0, 0.0, FALSE, FALSE);

-- Sample Work Logs
INSERT INTO work_logs (user_id, date, plan_id, actual_time, unplanned_work) VALUES
(4, CURDATE() - INTERVAL 7 DAY, 1, 6.0, 'Unexpected meeting'),
(5, CURDATE() - INTERVAL 3 DAY, 3, 7.0, 'Server issues'),
(6, CURDATE() - INTERVAL 2 DAY, 4, 2.0, NULL);

-- Sample Approvals
INSERT INTO approvals (plan_id, approved_by, role, status, comments) VALUES
(1, 3, 'Team Lead', 'Approved', 'Good work'),
(1, 2, 'Manager', 'Approved', 'Approved'),
(3, 3, 'Team Lead', 'Needs Rework', 'Please fix the issues mentioned'),
(4, 3, 'Team Lead', 'Rejected', 'Not aligned with project goals');
