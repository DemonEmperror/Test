package com.poa.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBConnectionUtil {
    private static final Logger LOGGER = Logger.getLogger(DBConnectionUtil.class.getName());
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/poa_db";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = ""; // Set your MySQL password here
    
    private static DataSource dataSource;
    
    static {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            LOGGER.log(Level.SEVERE, "MySQL JDBC Driver not found", e);
        }
        
        // Initialize connection pool if possible
        try {
            Context initContext = new InitialContext();
            Context envContext = (Context) initContext.lookup("java:/comp/env");
            dataSource = (DataSource) envContext.lookup("jdbc/poaDB");
            LOGGER.info("Connection pool initialized successfully");
        } catch (NamingException e) {
            LOGGER.log(Level.WARNING, "Could not initialize connection pool. Will use direct connections.", e);
        }
    }
    
    // Get connection from pool if available, otherwise create a new connection
    public static Connection getConnection() throws SQLException {
        if (dataSource != null) {
            return dataSource.getConnection();
        } else {
            LOGGER.info("Using direct database connection");
            return DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
        }
    }
    
    // Close connection
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                LOGGER.log(Level.WARNING, "Error closing connection", e);
            }
        }
    }
    
    // Rollback transaction
    public static void rollback(Connection connection) {
        if (connection != null) {
            try {
                connection.rollback();
            } catch (SQLException e) {
                LOGGER.log(Level.WARNING, "Error rolling back transaction", e);
            }
        }
    }
}
