package com.poa.util;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.poa.model.User;

public class SecurityUtil {
    private static final Logger LOGGER = Logger.getLogger(SecurityUtil.class.getName());
    
    // Hash password using SHA-256 (now just returns plain text)
    public static String hashPassword(String password) {
        // Return plain text password instead of hashing
        return password;
    }
    
    // Verify password (now just compares plain text)
    public static boolean verifyPassword(String password, String storedPassword) {
        // Simple plain text comparison
        return password != null && password.equals(storedPassword);
    }
    
    // Get logged in user from session
    public static User getLoggedInUser(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            return (User) session.getAttribute("user");
        }
        return null;
    }
    
    // Check if user is logged in
    public static boolean isLoggedIn(HttpServletRequest request) {
        return getLoggedInUser(request) != null;
    }
    
    // Check if user has specific role
    public static boolean hasRole(HttpServletRequest request, String role) {
        User user = getLoggedInUser(request);
        return user != null && user.hasRole(role);
    }
    
    // Check if user is admin
    public static boolean isAdmin(HttpServletRequest request) {
        User user = getLoggedInUser(request);
        return user != null && user.isAdmin();
    }
    
    // Check if user is manager
    public static boolean isManager(HttpServletRequest request) {
        User user = getLoggedInUser(request);
        return user != null && user.isManager();
    }
    
    // Check if user is team lead
    public static boolean isTeamLead(HttpServletRequest request) {
        User user = getLoggedInUser(request);
        return user != null && user.isTeamLead();
    }
    
    // Check if user is employee (SDE, JSDE, Intern)
    public static boolean isEmployee(HttpServletRequest request) {
        User user = getLoggedInUser(request);
        return user != null && user.isEmployee();
    }
    
    // Create CSRF token
    public static String generateCSRFToken(HttpServletRequest request) {
        HttpSession session = request.getSession(true);
        String token = hashPassword(session.getId() + System.currentTimeMillis());
        session.setAttribute("csrfToken", token);
        return token;
    }
    
    // Validate CSRF token
    public static boolean validateCSRFToken(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return false;
        }
        
        String sessionToken = (String) session.getAttribute("csrfToken");
        String requestToken = request.getParameter("csrfToken");
        
        return sessionToken != null && sessionToken.equals(requestToken);
    }
}
