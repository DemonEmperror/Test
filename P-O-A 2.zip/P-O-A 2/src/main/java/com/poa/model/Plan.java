package com.poa.model;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class Plan {
    private int id;
    private int userId;
    private Date date;
    private String status;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private List<PlanDeliverable> deliverables;
    private User user;
    private List<Approval> approvals;
    
    // Constructors
    public Plan() {
        this.deliverables = new ArrayList<>();
        this.approvals = new ArrayList<>();
    }
    
    public Plan(int id, int userId, Date date, String status) {
        this.id = id;
        this.userId = userId;
        this.date = date;
        this.status = status;
        this.deliverables = new ArrayList<>();
        this.approvals = new ArrayList<>();
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public Date getDate() {
        return date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public List<PlanDeliverable> getDeliverables() {
        return deliverables;
    }
    
    public void setDeliverables(List<PlanDeliverable> deliverables) {
        this.deliverables = deliverables;
    }
    
    public void addDeliverable(PlanDeliverable deliverable) {
        this.deliverables.add(deliverable);
    }
    
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        this.user = user;
    }
    
    public List<Approval> getApprovals() {
        return approvals;
    }
    
    public void setApprovals(List<Approval> approvals) {
        this.approvals = approvals;
    }
    
    public void addApproval(Approval approval) {
        this.approvals.add(approval);
    }
    
    // Helper methods
    public float getTotalEstimatedTime() {
        float total = 0;
        for (PlanDeliverable deliverable : deliverables) {
            total += deliverable.getEstimatedTime();
        }
        return total;
    }
    
    public float getTotalActualTime() {
        float total = 0;
        for (PlanDeliverable deliverable : deliverables) {
            total += deliverable.getActualTime();
        }
        return total;
    }
    
    public float getTotalOverflowHours() {
        float total = 0;
        for (PlanDeliverable deliverable : deliverables) {
            total += deliverable.getOverflowHours();
        }
        return total;
    }
    
    public int getCompletedDeliverables() {
        int count = 0;
        for (PlanDeliverable deliverable : deliverables) {
            if (deliverable.isAchieved()) {
                count++;
            }
        }
        return count;
    }
    
    public boolean isPending() {
        return "Pending".equals(status);
    }
    
    public boolean isApproved() {
        return "Approved".equals(status);
    }
    
    public boolean isRejected() {
        return "Rejected".equals(status);
    }
    
    public boolean needsRework() {
        return "Needs Rework".equals(status);
    }
}
