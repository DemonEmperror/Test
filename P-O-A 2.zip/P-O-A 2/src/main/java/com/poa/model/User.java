package com.poa.model;

import java.sql.Timestamp;

public class User {
    private int id;
    private String username;
    private String firstName;
    private String lastName;
    private String name;
    private String email;
    private String passwordHash;
    private String role;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    
    // Constructors
    public User() {}
    
    public User(int id, String name, String email, String passwordHash, String role) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.passwordHash = passwordHash;
        this.role = role;
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPasswordHash() {
        return passwordHash;
    }
    
    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }
    
    public String getPassword() {
        return passwordHash;
    }
    
    public void setPassword(String password) {
        this.passwordHash = password;
    }
    
    public String getRole() {
        return role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    // Check if user has specific role
    public boolean hasRole(String roleName) {
        return this.role.equals(roleName);
    }
    
    // Check if user is admin
    public boolean isAdmin() {
        return "Admin".equals(this.role);
    }
    
    // Check if user is manager
    public boolean isManager() {
        return "Manager".equals(this.role);
    }
    
    // Check if user is team lead
    public boolean isTeamLead() {
        return "Team Lead".equals(this.role);
    }
    
    // Check if user is any type of employee (SDE, JSDE, Intern)
    public boolean isEmployee() {
        return "SDE".equals(this.role) || "JSDE".equals(this.role) || "Intern".equals(this.role);
    }
}
