package com.poa.model;

import java.sql.Timestamp;

public class Approval {
    private int id;
    private int planId;
    private int approvedBy;
    private String role;
    private String status;
    private String comments;
    private Timestamp timestamp;
    private User approver;
    
    // Constructors
    public Approval() {}
    
    public Approval(int id, int planId, int approvedBy, String role, String status, String comments) {
        this.id = id;
        this.planId = planId;
        this.approvedBy = approvedBy;
        this.role = role;
        this.status = status;
        this.comments = comments;
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getPlanId() {
        return planId;
    }
    
    public void setPlanId(int planId) {
        this.planId = planId;
    }
    
    public int getApprovedBy() {
        return approvedBy;
    }
    
    public void setApprovedBy(int approvedBy) {
        this.approvedBy = approvedBy;
    }
    
    public String getRole() {
        return role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getComments() {
        return comments;
    }
    
    public void setComments(String comments) {
        this.comments = comments;
    }
    
    public Timestamp getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
    
    public User getApprover() {
        return approver;
    }
    
    public void setApprover(User approver) {
        this.approver = approver;
    }
    
    // Helper methods
    public boolean isApproved() {
        return "Approved".equals(status);
    }
    
    public boolean isRejected() {
        return "Rejected".equals(status);
    }
    
    public boolean isPending() {
        return "Pending".equals(status);
    }
    
    public boolean needsRework() {
        return "Needs Rework".equals(status);
    }
    
    public boolean isTeamLeadApproval() {
        return "Team Lead".equals(role);
    }
    
    public boolean isManagerApproval() {
        return "Manager".equals(role);
    }
}
