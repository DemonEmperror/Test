package com.poa.model;

import java.sql.Timestamp;

public class PlanDeliverable {
    private int id;
    private int planId;
    private String description;
    private float estimatedTime;
    private float actualTime;
    private float overflowHours;
    private boolean rework;
    private boolean achieved;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    
    // Constructors
    public PlanDeliverable() {}
    
    public PlanDeliverable(int id, int planId, String description, float estimatedTime) {
        this.id = id;
        this.planId = planId;
        this.description = description;
        this.estimatedTime = estimatedTime;
        this.actualTime = 0;
        this.overflowHours = 0;
        this.rework = false;
        this.achieved = false;
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getPlanId() {
        return planId;
    }
    
    public void setPlanId(int planId) {
        this.planId = planId;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public float getEstimatedTime() {
        return estimatedTime;
    }
    
    public void setEstimatedTime(float estimatedTime) {
        this.estimatedTime = estimatedTime;
    }
    
    public float getActualTime() {
        return actualTime;
    }
    
    public void setActualTime(float actualTime) {
        this.actualTime = actualTime;
        // Calculate overflow hours
        if (actualTime > estimatedTime) {
            this.overflowHours = actualTime - estimatedTime;
        }
    }
    
    public float getOverflowHours() {
        return overflowHours;
    }
    
    public void setOverflowHours(float overflowHours) {
        this.overflowHours = overflowHours;
    }
    
    public boolean isRework() {
        return rework;
    }
    
    public void setRework(boolean rework) {
        this.rework = rework;
    }
    
    public boolean isAchieved() {
        return achieved;
    }
    
    public void setAchieved(boolean achieved) {
        this.achieved = achieved;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    // Helper methods
    public boolean isCompleted() {
        return actualTime > 0 && achieved;
    }
    
    public boolean hasOverflow() {
        return overflowHours > 0;
    }
}
