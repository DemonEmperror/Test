package com.poa.model;

import java.sql.Date;
import java.sql.Timestamp;

public class WorkLog {
    private int id;
    private int userId;
    private Date date;
    private Integer planId; // Can be null for unplanned work
    private float actualTime;
    private String unplannedWork;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private User user;
    private Plan plan;
    
    // Constructors
    public WorkLog() {}
    
    public WorkLog(int id, int userId, Date date, Integer planId, float actualTime, String unplannedWork) {
        this.id = id;
        this.userId = userId;
        this.date = date;
        this.planId = planId;
        this.actualTime = actualTime;
        this.unplannedWork = unplannedWork;
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public Date getDate() {
        return date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }
    
    public Integer getPlanId() {
        return planId;
    }
    
    public void setPlanId(Integer planId) {
        this.planId = planId;
    }
    
    public float getActualTime() {
        return actualTime;
    }
    
    public void setActualTime(float actualTime) {
        this.actualTime = actualTime;
    }
    
    public String getUnplannedWork() {
        return unplannedWork;
    }
    
    public void setUnplannedWork(String unplannedWork) {
        this.unplannedWork = unplannedWork;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        this.user = user;
    }
    
    public Plan getPlan() {
        return plan;
    }
    
    public void setPlan(Plan plan) {
        this.plan = plan;
    }
    
    // Helper methods
    public boolean isPlanned() {
        return planId != null;
    }
    
    public boolean hasUnplannedWork() {
        return unplannedWork != null && !unplannedWork.trim().isEmpty();
    }
    
    public boolean isUnplanned() {
        return planId == null || planId <= 0;
    }
}
