package com.poa.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.poa.dao.PlanDAO;
import com.poa.dao.UserDAO;
import com.poa.dao.WorkLogDAO;
import com.poa.model.Plan;
import com.poa.model.User;
import com.poa.model.WorkLog;
import com.poa.util.DateUtil;
import com.poa.util.SecurityUtil;

public class ReportController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private PlanDAO planDAO = new PlanDAO();
    private WorkLogDAO workLogDAO = new WorkLogDAO();
    private UserDAO userDAO = new UserDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        if (!SecurityUtil.isLoggedIn(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String path = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        // Get logged in user
        User user = SecurityUtil.getLoggedInUser(request);
        
        // Only managers, team leads, and admins can access reports
        if (!user.isManager() && !user.isTeamLead() && !user.isAdmin()) {
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        // Get date range parameters
        String startDateStr = request.getParameter("startDate");
        String endDateStr = request.getParameter("endDate");
        
        // Set default date range if not provided
        Date startDate = null;
        Date endDate = null;
        
        if (startDateStr == null || startDateStr.trim().isEmpty()) {
            // Default to current week
            startDate = DateUtil.getStartOfWeek(DateUtil.getCurrentDate());
        } else {
            startDate = DateUtil.parseDate(startDateStr);
        }
        
        if (endDateStr == null || endDateStr.trim().isEmpty()) {
            // Default to current date
            endDate = DateUtil.getCurrentDate();
        } else {
            endDate = DateUtil.parseDate(endDateStr);
        }
        
        // Set date range attributes
        request.setAttribute("startDate", DateUtil.formatDate(startDate));
        request.setAttribute("endDate", DateUtil.formatDate(endDate));
        
        switch (path) {
            case "/reports":
                // Show report options
                request.getRequestDispatcher("/WEB-INF/views/reports/index.jsp").forward(request, response);
                break;
                
            case "/reports/daily":
                // Daily report
                Date reportDate = (startDate != null) ? startDate : DateUtil.getCurrentDate();
                
                // Get all plans for the day
                List<Plan> dailyPlans = planDAO.findByDateRange(reportDate, reportDate);
                request.setAttribute("plans", dailyPlans);
                
                // Get all work logs for the day
                List<WorkLog> dailyWorkLogs = workLogDAO.findByDateRange(reportDate, reportDate);
                request.setAttribute("workLogs", dailyWorkLogs);
                
                // Calculate statistics
                calculateStatistics(request, dailyPlans, dailyWorkLogs);
                
                request.getRequestDispatcher("/WEB-INF/views/reports/daily.jsp").forward(request, response);
                break;
                
            case "/reports/weekly":
                // Weekly report
                Date weekStart = DateUtil.getStartOfWeek(startDate);
                Date weekEnd = DateUtil.getEndOfWeek(startDate);
                
                // Get all plans for the week
                List<Plan> weeklyPlans = planDAO.findByDateRange(weekStart, weekEnd);
                request.setAttribute("plans", weeklyPlans);
                
                // Get all work logs for the week
                List<WorkLog> weeklyWorkLogs = workLogDAO.findByDateRange(weekStart, weekEnd);
                request.setAttribute("workLogs", weeklyWorkLogs);
                
                // Calculate statistics
                calculateStatistics(request, weeklyPlans, weeklyWorkLogs);
                
                // Set week range
                request.setAttribute("weekStart", DateUtil.formatDate(weekStart));
                request.setAttribute("weekEnd", DateUtil.formatDate(weekEnd));
                
                request.getRequestDispatcher("/WEB-INF/views/reports/weekly.jsp").forward(request, response);
                break;
                
            case "/reports/monthly":
                // Monthly report
                Date monthStart = DateUtil.getStartOfMonth(startDate);
                Date monthEnd = DateUtil.getEndOfMonth(startDate);
                
                // Get all plans for the month
                List<Plan> monthlyPlans = planDAO.findByDateRange(monthStart, monthEnd);
                request.setAttribute("plans", monthlyPlans);
                
                // Get all work logs for the month
                List<WorkLog> monthlyWorkLogs = workLogDAO.findByDateRange(monthStart, monthEnd);
                request.setAttribute("workLogs", monthlyWorkLogs);
                
                // Calculate statistics
                calculateStatistics(request, monthlyPlans, monthlyWorkLogs);
                
                // Set month range
                request.setAttribute("monthStart", DateUtil.formatDate(monthStart));
                request.setAttribute("monthEnd", DateUtil.formatDate(monthEnd));
                
                request.getRequestDispatcher("/WEB-INF/views/reports/monthly.jsp").forward(request, response);
                break;
                
            case "/reports/user":
                // User-specific report
                if (pathInfo == null || pathInfo.equals("/")) {
                    // Show list of users
                    List<User> users = userDAO.findAll();
                    request.setAttribute("users", users);
                    request.getRequestDispatcher("/WEB-INF/views/reports/users.jsp").forward(request, response);
                    return;
                }
                
                int userId = Integer.parseInt(pathInfo.substring(1));
                User targetUser = userDAO.findById(userId);
                
                if (targetUser == null) {
                    response.sendRedirect(request.getContextPath() + "/reports/user");
                    return;
                }
                
                // Get all plans for the user within date range
                List<Plan> userPlans = planDAO.findByUserIdAndDateRange(userId, startDate, endDate);
                request.setAttribute("plans", userPlans);
                
                // Get all work logs for the user within date range
                List<WorkLog> userWorkLogs = workLogDAO.findByUserIdAndDateRange(userId, startDate, endDate);
                request.setAttribute("workLogs", userWorkLogs);
                
                // Calculate statistics
                calculateStatistics(request, userPlans, userWorkLogs);
                
                // Set user attribute
                request.setAttribute("targetUser", targetUser);
                
                request.getRequestDispatcher("/WEB-INF/views/reports/user.jsp").forward(request, response);
                break;
                
            default:
                response.sendRedirect(request.getContextPath() + "/reports");
                break;
        }
    }
    
    /**
     * Calculate statistics based on plans and work logs
     * 
     * @param request The HTTP request
     * @param plans List of plans
     * @param workLogs List of work logs
     */
    private void calculateStatistics(HttpServletRequest request, List<Plan> plans, List<WorkLog> workLogs) {
        // Initialize statistics
        float totalEstimatedTime = 0;
        float totalActualTime = 0;
        float totalOverflowHours = 0;
        float totalUnplannedTime = 0;
        int totalPlans = plans.size();
        int approvedPlans = 0;
        int rejectedPlans = 0;
        int pendingPlans = 0;
        int needsReworkPlans = 0;
        
        // Calculate plan statistics
        for (Plan plan : plans) {
            // Count plans by status
            if (plan.isApproved()) {
                approvedPlans++;
            } else if (plan.isRejected()) {
                rejectedPlans++;
            } else if (plan.isPending()) {
                pendingPlans++;
            } else if (plan.needsRework()) {
                needsReworkPlans++;
            }
            
            // Sum estimated time
            totalEstimatedTime += plan.getTotalEstimatedTime();
            
            // Sum actual time and overflow hours
            totalActualTime += plan.getTotalActualTime();
            totalOverflowHours += plan.getTotalOverflowHours();
        }
        
        // Calculate work log statistics
        for (WorkLog workLog : workLogs) {
            // Check if work log is unplanned
            if (workLog.isUnplanned()) {
                totalUnplannedTime += workLog.getActualTime();
            }
        }
        
        // Calculate efficiency (actual time / estimated time)
        float efficiency = (totalEstimatedTime > 0) ? (totalActualTime / totalEstimatedTime) * 100 : 0;
        
        // Calculate percentage of unplanned work
        float totalTime = totalActualTime + totalUnplannedTime;
        float unplannedPercentage = (totalTime > 0) ? (totalUnplannedTime / totalTime) * 100 : 0;
        
        // Set statistics attributes
        request.setAttribute("totalEstimatedTime", totalEstimatedTime);
        request.setAttribute("totalActualTime", totalActualTime);
        request.setAttribute("totalOverflowHours", totalOverflowHours);
        request.setAttribute("totalUnplannedTime", totalUnplannedTime);
        request.setAttribute("totalPlans", totalPlans);
        request.setAttribute("approvedPlans", approvedPlans);
        request.setAttribute("rejectedPlans", rejectedPlans);
        request.setAttribute("pendingPlans", pendingPlans);
        request.setAttribute("needsReworkPlans", needsReworkPlans);
        request.setAttribute("efficiency", efficiency);
        request.setAttribute("unplannedPercentage", unplannedPercentage);
        
        // Calculate user-specific statistics
        Map<Integer, UserStats> userStatsMap = new HashMap<>();
        
        // Process plans by user
        for (Plan plan : plans) {
            UserStats stats = userStatsMap.getOrDefault(plan.getUserId(), new UserStats());
            stats.totalPlans++;
            
            if (plan.isApproved()) {
                stats.approvedPlans++;
            } else if (plan.isRejected()) {
                stats.rejectedPlans++;
            } else if (plan.isPending()) {
                stats.pendingPlans++;
            } else if (plan.needsRework()) {
                stats.needsReworkPlans++;
            }
            
            stats.estimatedTime += plan.getTotalEstimatedTime();
            stats.actualTime += plan.getTotalActualTime();
            stats.overflowHours += plan.getTotalOverflowHours();
            
            userStatsMap.put(plan.getUserId(), stats);
        }
        
        // Process work logs by user
        for (WorkLog workLog : workLogs) {
            UserStats stats = userStatsMap.getOrDefault(workLog.getUserId(), new UserStats());
            
            if (workLog.isUnplanned()) {
                stats.unplannedTime += workLog.getActualTime();
            }
            
            userStatsMap.put(workLog.getUserId(), stats);
        }
        
        // Set user statistics attribute
        request.setAttribute("userStatsMap", userStatsMap);
    }
    
    /**
     * Inner class to hold user statistics
     */
    private class UserStats {
        int totalPlans = 0;
        int approvedPlans = 0;
        int rejectedPlans = 0;
        int pendingPlans = 0;
        int needsReworkPlans = 0;
        float estimatedTime = 0;
        float actualTime = 0;
        float overflowHours = 0;
        float unplannedTime = 0;
        
        public float getEfficiency() {
            return (estimatedTime > 0) ? (actualTime / estimatedTime) * 100 : 0;
        }
        
        public float getUnplannedPercentage() {
            float totalTime = actualTime + unplannedTime;
            return (totalTime > 0) ? (unplannedTime / totalTime) * 100 : 0;
        }
    }
}
