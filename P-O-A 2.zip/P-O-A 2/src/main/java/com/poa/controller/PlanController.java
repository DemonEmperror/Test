package com.poa.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.poa.dao.ApprovalDAO;
import com.poa.dao.PlanDAO;
import com.poa.dao.PlanDeliverableDAO;
import com.poa.model.Approval;
import com.poa.model.Plan;
import com.poa.model.PlanDeliverable;
import com.poa.model.User;
import com.poa.util.DateUtil;
import com.poa.util.SecurityUtil;

public class PlanController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private PlanDAO planDAO = new PlanDAO();
    private PlanDeliverableDAO deliverableDAO = new PlanDeliverableDAO();
    private ApprovalDAO approvalDAO = new ApprovalDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        if (!SecurityUtil.isLoggedIn(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String path = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        // Get logged in user
        User user = SecurityUtil.getLoggedInUser(request);
        
        // Generate CSRF token
        String csrfToken = SecurityUtil.generateCSRFToken(request);
        request.setAttribute("csrfToken", csrfToken);
        
        switch (path) {
            case "/plans":
                // List all plans
                if (user.isEmployee()) {
                    // Employees can only see their own plans
                    List<Plan> plans = planDAO.findByUserId(user.getId());
                    request.setAttribute("plans", plans);
                } else {
                    // Managers, Team Leads, and Admins can see all plans
                    List<Plan> plans = planDAO.findAll();
                    request.setAttribute("plans", plans);
                }
                
                request.getRequestDispatcher("/WEB-INF/views/plans/list.jsp").forward(request, response);
                break;
                
            case "/plans/create":
                // Only employees can create plans
                if (!user.isEmployee() && !user.isAdmin()) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Set today's date as default
                request.setAttribute("today", DateUtil.formatDate(DateUtil.getCurrentDate()));
                
                request.getRequestDispatcher("/WEB-INF/views/plans/create.jsp").forward(request, response);
                break;
                
            case "/plans/edit":
                // Edit plan
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                int planId = Integer.parseInt(pathInfo.substring(1));
                Plan plan = planDAO.findById(planId);
                
                if (plan == null) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Check if user is authorized to edit this plan
                if (user.isEmployee() && plan.getUserId() != user.getId()) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Check if plan is editable (only pending or needs rework plans can be edited)
                if (!plan.isPending() && !plan.needsRework()) {
                    request.getSession().setAttribute("error", "This plan cannot be edited because it is already " + plan.getStatus());
                    response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
                    return;
                }
                
                request.setAttribute("plan", plan);
                request.getRequestDispatcher("/WEB-INF/views/plans/edit.jsp").forward(request, response);
                break;
                
            case "/plans/view":
                // View plan details
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                planId = Integer.parseInt(pathInfo.substring(1));
                plan = planDAO.findById(planId);
                
                if (plan == null) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Check if user is authorized to view this plan
                if (user.isEmployee() && plan.getUserId() != user.getId()) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                request.setAttribute("plan", plan);
                request.getRequestDispatcher("/WEB-INF/views/plans/view.jsp").forward(request, response);
                break;
                
            case "/plans/delete":
                // Delete plan
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                planId = Integer.parseInt(pathInfo.substring(1));
                plan = planDAO.findById(planId);
                
                if (plan == null) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Check if user is authorized to delete this plan
                if (user.isEmployee() && plan.getUserId() != user.getId()) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Only pending plans can be deleted
                if (!plan.isPending()) {
                    request.getSession().setAttribute("error", "This plan cannot be deleted because it is already " + plan.getStatus());
                    response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
                    return;
                }
                
                request.setAttribute("plan", plan);
                request.getRequestDispatcher("/WEB-INF/views/plans/delete.jsp").forward(request, response);
                break;
                
            case "/plans/approve":
            case "/plans/reject":
            case "/plans/rework":
                // Approve/Reject/Rework plan
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Check if user is authorized to approve/reject plans
                if (!user.isManager() && !user.isTeamLead()) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                planId = Integer.parseInt(pathInfo.substring(1));
                plan = planDAO.findById(planId);
                
                if (plan == null) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Only pending plans can be approved/rejected/reworked
                if (!plan.isPending() && !plan.needsRework()) {
                    request.getSession().setAttribute("error", "This plan cannot be processed because it is already " + plan.getStatus());
                    response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
                    return;
                }
                
                String action = path.substring(path.lastIndexOf("/") + 1);
                request.setAttribute("action", action);
                request.setAttribute("plan", plan);
                request.getRequestDispatcher("/WEB-INF/views/plans/approval.jsp").forward(request, response);
                break;
                
            default:
                response.sendRedirect(request.getContextPath() + "/plans");
                break;
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        if (!SecurityUtil.isLoggedIn(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Validate CSRF token
        if (!SecurityUtil.validateCSRFToken(request)) {
            request.getSession().setAttribute("error", "Invalid request. Please try again.");
            response.sendRedirect(request.getContextPath() + "/plans");
            return;
        }
        
        String path = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        // Get logged in user
        User user = SecurityUtil.getLoggedInUser(request);
        
        switch (path) {
            case "/plans/create":
                // Create new plan
                
                // Only employees can create plans
                if (!user.isEmployee() && !user.isAdmin()) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Get form data
                String dateStr = request.getParameter("date");
                String[] descriptions = request.getParameterValues("description");
                String[] estimatedTimes = request.getParameterValues("estimatedTime");
                
                // Validate form data
                if (dateStr == null || dateStr.trim().isEmpty() || 
                    descriptions == null || descriptions.length == 0 || 
                    estimatedTimes == null || estimatedTimes.length == 0 || 
                    descriptions.length != estimatedTimes.length) {
                    
                    request.setAttribute("error", "All fields are required.");
                    request.setAttribute("today", DateUtil.formatDate(DateUtil.getCurrentDate()));
                    request.getRequestDispatcher("/WEB-INF/views/plans/create.jsp").forward(request, response);
                    return;
                }
                
                // Create new plan
                Plan plan = new Plan();
                plan.setUserId(user.getId());
                plan.setDate(DateUtil.parseDate(dateStr));
                plan.setStatus("Pending");
                
                // Create deliverables
                List<PlanDeliverable> deliverables = new ArrayList<>();
                for (int i = 0; i < descriptions.length; i++) {
                    if (descriptions[i] != null && !descriptions[i].trim().isEmpty() && 
                        estimatedTimes[i] != null && !estimatedTimes[i].trim().isEmpty()) {
                        
                        PlanDeliverable deliverable = new PlanDeliverable();
                        deliverable.setDescription(descriptions[i].trim());
                        deliverable.setEstimatedTime(Float.parseFloat(estimatedTimes[i].trim()));
                        deliverables.add(deliverable);
                    }
                }
                
                plan.setDeliverables(deliverables);
                
                // Save plan to database
                Plan createdPlan = planDAO.create(plan);
                
                if (createdPlan == null) {
                    request.setAttribute("error", "Failed to create plan. Please try again.");
                    request.setAttribute("today", DateUtil.formatDate(DateUtil.getCurrentDate()));
                    request.getRequestDispatcher("/WEB-INF/views/plans/create.jsp").forward(request, response);
                    return;
                }
                
                // Set success message and redirect to plan view
                request.getSession().setAttribute("success", "Plan created successfully.");
                response.sendRedirect(request.getContextPath() + "/plans/view/" + createdPlan.getId());
                break;
                
            case "/plans/edit":
                // Edit plan
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                int planId = Integer.parseInt(pathInfo.substring(1));
                Plan existingPlan = planDAO.findById(planId);
                
                if (existingPlan == null) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Check if user is authorized to edit this plan
                if (user.isEmployee() && existingPlan.getUserId() != user.getId()) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Check if plan is editable (only pending or needs rework plans can be edited)
                if (!existingPlan.isPending() && !existingPlan.needsRework()) {
                    request.getSession().setAttribute("error", "This plan cannot be edited because it is already " + existingPlan.getStatus());
                    response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
                    return;
                }
                
                // Get form data
                dateStr = request.getParameter("date");
                String[] ids = request.getParameterValues("id");
                descriptions = request.getParameterValues("description");
                estimatedTimes = request.getParameterValues("estimatedTime");
                String[] actualTimes = request.getParameterValues("actualTime");
                String[] overflowHours = request.getParameterValues("overflowHours");
                String[] reworks = request.getParameterValues("rework");
                String[] achieveds = request.getParameterValues("achieved");
                
                // Validate form data
                if (dateStr == null || dateStr.trim().isEmpty() || 
                    descriptions == null || descriptions.length == 0 || 
                    estimatedTimes == null || estimatedTimes.length == 0 || 
                    descriptions.length != estimatedTimes.length) {
                    
                    request.setAttribute("error", "All fields are required.");
                    request.setAttribute("plan", existingPlan);
                    request.getRequestDispatcher("/WEB-INF/views/plans/edit.jsp").forward(request, response);
                    return;
                }
                
                // Update plan
                existingPlan.setDate(DateUtil.parseDate(dateStr));
                
                // If plan was in "Needs Rework" status, change it back to "Pending"
                if (existingPlan.needsRework()) {
                    existingPlan.setStatus("Pending");
                }
                
                // Update deliverables
                List<PlanDeliverable> updatedDeliverables = new ArrayList<>();
                for (int i = 0; i < descriptions.length; i++) {
                    if (descriptions[i] != null && !descriptions[i].trim().isEmpty() && 
                        estimatedTimes[i] != null && !estimatedTimes[i].trim().isEmpty()) {
                        
                        PlanDeliverable deliverable = new PlanDeliverable();
                        
                        // Set ID if it exists
                        if (ids != null && i < ids.length && ids[i] != null && !ids[i].trim().isEmpty()) {
                            deliverable.setId(Integer.parseInt(ids[i].trim()));
                        }
                        
                        deliverable.setPlanId(planId);
                        deliverable.setDescription(descriptions[i].trim());
                        deliverable.setEstimatedTime(Float.parseFloat(estimatedTimes[i].trim()));
                        
                        // Set actual time if provided
                        if (actualTimes != null && i < actualTimes.length && actualTimes[i] != null && !actualTimes[i].trim().isEmpty()) {
                            deliverable.setActualTime(Float.parseFloat(actualTimes[i].trim()));
                        }
                        
                        // Set overflow hours if provided
                        if (overflowHours != null && i < overflowHours.length && overflowHours[i] != null && !overflowHours[i].trim().isEmpty()) {
                            deliverable.setOverflowHours(Float.parseFloat(overflowHours[i].trim()));
                        }
                        
                        // Set rework flag
                        deliverable.setRework(reworks != null && i < reworks.length && reworks[i] != null);
                        
                        // Set achieved flag
                        deliverable.setAchieved(achieveds != null && i < achieveds.length && achieveds[i] != null);
                        
                        updatedDeliverables.add(deliverable);
                    }
                }
                
                existingPlan.setDeliverables(updatedDeliverables);
                
                // Save plan to database
                boolean updated = planDAO.update(existingPlan);
                
                if (!updated) {
                    request.setAttribute("error", "Failed to update plan. Please try again.");
                    request.setAttribute("plan", existingPlan);
                    request.getRequestDispatcher("/WEB-INF/views/plans/edit.jsp").forward(request, response);
                    return;
                }
                
                // Set success message and redirect to plan view
                request.getSession().setAttribute("success", "Plan updated successfully.");
                response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
                break;
                
            case "/plans/delete":
                // Delete plan
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                planId = Integer.parseInt(pathInfo.substring(1));
                existingPlan = planDAO.findById(planId);
                
                if (existingPlan == null) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Check if user is authorized to delete this plan
                if (user.isEmployee() && existingPlan.getUserId() != user.getId()) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Only pending plans can be deleted
                if (!existingPlan.isPending()) {
                    request.getSession().setAttribute("error", "This plan cannot be deleted because it is already " + existingPlan.getStatus());
                    response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
                    return;
                }
                
                // Delete plan
                boolean deleted = planDAO.delete(planId);
                
                if (!deleted) {
                    request.getSession().setAttribute("error", "Failed to delete plan. Please try again.");
                    response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
                    return;
                }
                
                // Set success message and redirect to plans list
                request.getSession().setAttribute("success", "Plan deleted successfully.");
                response.sendRedirect(request.getContextPath() + "/plans");
                break;
                
            case "/plans/approve":
            case "/plans/reject":
            case "/plans/rework":
                // Approve/Reject/Rework plan
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Check if user is authorized to approve/reject plans
                if (!user.isManager() && !user.isTeamLead()) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                planId = Integer.parseInt(pathInfo.substring(1));
                existingPlan = planDAO.findById(planId);
                
                if (existingPlan == null) {
                    response.sendRedirect(request.getContextPath() + "/plans");
                    return;
                }
                
                // Only pending plans can be approved/rejected/reworked
                if (!existingPlan.isPending() && !existingPlan.needsRework()) {
                    request.getSession().setAttribute("error", "This plan cannot be processed because it is already " + existingPlan.getStatus());
                    response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
                    return;
                }
                
                // Get form data
                String comments = request.getParameter("comments");
                
                // Create approval record
                Approval approval = new Approval();
                approval.setPlanId(planId);
                approval.setApprovedBy(user.getId());
                approval.setRole(user.getRole());
                approval.setComments(comments);
                
                String action = path.substring(path.lastIndexOf("/") + 1);
                String status = "";
                
                switch (action) {
                    case "approve":
                        status = "Approved";
                        break;
                    case "reject":
                        status = "Rejected";
                        break;
                    case "rework":
                        status = "Needs Rework";
                        break;
                }
                
                approval.setStatus(status);
                
                // Save approval to database
                Approval createdApproval = approvalDAO.create(approval);
                
                if (createdApproval == null) {
                    request.getSession().setAttribute("error", "Failed to process plan. Please try again.");
                    response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
                    return;
                }
                
                // Update plan status
                existingPlan.setStatus(status);
                boolean planUpdated = planDAO.update(existingPlan);
                
                if (!planUpdated) {
                    request.getSession().setAttribute("error", "Failed to update plan status. Please try again.");
                    response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
                    return;
                }
                
                // Set success message and redirect to plan view
                request.getSession().setAttribute("success", "Plan " + status.toLowerCase() + " successfully.");
                response.sendRedirect(request.getContextPath() + "/plans/view/" + planId);
                break;
                
            default:
                response.sendRedirect(request.getContextPath() + "/plans");
                break;
        }
    }
}
