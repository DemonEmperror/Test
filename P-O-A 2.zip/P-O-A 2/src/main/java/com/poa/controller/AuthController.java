package com.poa.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.poa.dao.UserDAO;
import com.poa.model.User;
import com.poa.util.SecurityUtil;

public class AuthController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO = new UserDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();
        
        switch (path) {
            case "/login":
                // If user is already logged in, redirect to dashboard
                if (SecurityUtil.isLoggedIn(request)) {
                    response.sendRedirect(request.getContextPath() + "/dashboard");
                    return;
                }
                
                // Generate CSRF token for login form
                String csrfToken = SecurityUtil.generateCSRFToken(request);
                request.setAttribute("csrfToken", csrfToken);
                
                // Forward to login page
                request.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(request, response);
                break;
                
            case "/logout":
                // Invalidate session
                HttpSession session = request.getSession(false);
                if (session != null) {
                    session.invalidate();
                }
                
                // Redirect to login page
                response.sendRedirect(request.getContextPath() + "/login");
                break;
                
            case "/register":
                // If user is already logged in, redirect to dashboard
                if (SecurityUtil.isLoggedIn(request)) {
                    response.sendRedirect(request.getContextPath() + "/dashboard");
                    return;
                }
                
                // Only admin can access register page
                if (!SecurityUtil.isAdmin(request)) {
                    response.sendRedirect(request.getContextPath() + "/login");
                    return;
                }
                
                // Generate CSRF token for register form
                csrfToken = SecurityUtil.generateCSRFToken(request);
                request.setAttribute("csrfToken", csrfToken);
                
                // Forward to register page
                request.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(request, response);
                break;
                
            default:
                response.sendRedirect(request.getContextPath() + "/login");
                break;
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();
        
        switch (path) {
            case "/login":
                // Validate CSRF token
                if (!SecurityUtil.validateCSRFToken(request)) {
                    request.setAttribute("error", "Invalid request. Please try again.");
                    request.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(request, response);
                    return;
                }
                
                // Get form data
                String email = request.getParameter("email");
                String password = request.getParameter("password");
                
                // Validate form data
                if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
                    request.setAttribute("error", "Email and password are required.");
                    request.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(request, response);
                    return;
                }
                
                // Find user by email
                User user = userDAO.findByEmail(email);
                
                // Validate user and password
                if (user == null || !SecurityUtil.verifyPassword(password, user.getPasswordHash())) {
                    request.setAttribute("error", "Invalid email or password.");
                    request.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(request, response);
                    return;
                }
                
                // Create session and store user
                HttpSession session = request.getSession(true);
                session.setAttribute("user", user);
                
                // Redirect to dashboard
                response.sendRedirect(request.getContextPath() + "/dashboard");
                break;
                
            case "/register":
                // Validate CSRF token
                if (!SecurityUtil.validateCSRFToken(request)) {
                    request.setAttribute("error", "Invalid request. Please try again.");
                    request.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(request, response);
                    return;
                }
                
                // Only admin can register new users
                if (!SecurityUtil.isAdmin(request)) {
                    response.sendRedirect(request.getContextPath() + "/login");
                    return;
                }
                
                // Get form data
                String name = request.getParameter("name");
                email = request.getParameter("email");
                password = request.getParameter("password");
                String confirmPassword = request.getParameter("confirmPassword");
                String role = request.getParameter("role");
                
                // Validate form data
                if (name == null || name.trim().isEmpty() || 
                    email == null || email.trim().isEmpty() || 
                    password == null || password.trim().isEmpty() || 
                    confirmPassword == null || confirmPassword.trim().isEmpty() || 
                    role == null || role.trim().isEmpty()) {
                    
                    request.setAttribute("error", "All fields are required.");
                    request.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(request, response);
                    return;
                }
                
                // Validate password match
                if (!password.equals(confirmPassword)) {
                    request.setAttribute("error", "Passwords do not match.");
                    request.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(request, response);
                    return;
                }
                
                // Check if email already exists
                User existingUser = userDAO.findByEmail(email);
                if (existingUser != null) {
                    request.setAttribute("error", "Email already exists.");
                    request.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(request, response);
                    return;
                }
                
                // Create new user
                User newUser = new User();
                newUser.setName(name);
                newUser.setEmail(email);
                newUser.setPasswordHash(SecurityUtil.hashPassword(password));
                newUser.setRole(role);
                
                // Save user to database
                User createdUser = userDAO.create(newUser);
                
                if (createdUser == null) {
                    request.setAttribute("error", "Failed to create user. Please try again.");
                    request.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(request, response);
                    return;
                }
                
                // Set success message and redirect to users list
                request.getSession().setAttribute("success", "User created successfully.");
                response.sendRedirect(request.getContextPath() + "/users");
                break;
                
            default:
                response.sendRedirect(request.getContextPath() + "/login");
                break;
        }
    }
}
