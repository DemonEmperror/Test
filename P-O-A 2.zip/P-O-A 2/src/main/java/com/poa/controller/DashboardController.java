package com.poa.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.poa.dao.ApprovalDAO;
import com.poa.dao.PlanDAO;
import com.poa.dao.UserDAO;
import com.poa.dao.WorkLogDAO;
import com.poa.model.Approval;
import com.poa.model.Plan;
import com.poa.model.User;
import com.poa.model.WorkLog;
import com.poa.util.DateUtil;
import com.poa.util.SecurityUtil;

public class DashboardController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private PlanDAO planDAO = new PlanDAO();
    private ApprovalDAO approvalDAO = new ApprovalDAO();
    private WorkLogDAO workLogDAO = new WorkLogDAO();
    private UserDAO userDAO = new UserDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        if (!SecurityUtil.isLoggedIn(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        User user = SecurityUtil.getLoggedInUser(request);
        
        // Get date range parameters (default to current week)
        String startDateStr = request.getParameter("startDate");
        String endDateStr = request.getParameter("endDate");
        
        Date startDate = (startDateStr != null) ? DateUtil.parseDate(startDateStr) : DateUtil.getFirstDayOfWeek();
        Date endDate = (endDateStr != null) ? DateUtil.parseDate(endDateStr) : DateUtil.getLastDayOfWeek();
        
        if (startDate == null) startDate = DateUtil.getFirstDayOfWeek();
        if (endDate == null) endDate = DateUtil.getLastDayOfWeek();
        
        // Set date range for the view
        request.setAttribute("startDate", DateUtil.formatDate(startDate));
        request.setAttribute("endDate", DateUtil.formatDate(endDate));
        
        // Different dashboard based on user role
        if (user.isAdmin()) {
            // Admin dashboard - system overview
            List<User> users = userDAO.findAll();
            List<Plan> allPlans = planDAO.findByDateRange(startDate, endDate);
            
            request.setAttribute("totalUsers", users.size());
            request.setAttribute("plans", allPlans);
            
            // Count plans by status
            int pendingCount = 0;
            int approvedCount = 0;
            int rejectedCount = 0;
            int reworkCount = 0;
            
            for (Plan plan : allPlans) {
                if (plan.isPending()) pendingCount++;
                else if (plan.isApproved()) approvedCount++;
                else if (plan.isRejected()) rejectedCount++;
                else if (plan.needsRework()) reworkCount++;
            }
            
            request.setAttribute("pendingCount", pendingCount);
            request.setAttribute("approvedCount", approvedCount);
            request.setAttribute("rejectedCount", rejectedCount);
            request.setAttribute("reworkCount", reworkCount);
            
            request.getRequestDispatcher("/WEB-INF/views/dashboard/admin.jsp").forward(request, response);
        } else if (user.isManager()) {
            // Manager dashboard - all plans, approval stats
            List<Plan> pendingPlans = planDAO.findByStatus("Pending");
            List<Plan> allPlans = planDAO.findByDateRange(startDate, endDate);
            List<Approval> recentApprovals = approvalDAO.findByApproverId(user.getId());
            
            request.setAttribute("pendingPlans", pendingPlans);
            request.setAttribute("allPlans", allPlans);
            request.setAttribute("recentApprovals", recentApprovals);
            
            // Count plans by status
            int pendingCount = 0;
            int approvedCount = 0;
            int rejectedCount = 0;
            int reworkCount = 0;
            
            for (Plan plan : allPlans) {
                if (plan.isPending()) pendingCount++;
                else if (plan.isApproved()) approvedCount++;
                else if (plan.isRejected()) rejectedCount++;
                else if (plan.needsRework()) reworkCount++;
            }
            
            request.setAttribute("pendingCount", pendingCount);
            request.setAttribute("approvedCount", approvedCount);
            request.setAttribute("rejectedCount", rejectedCount);
            request.setAttribute("reworkCount", reworkCount);
            
            request.getRequestDispatcher("/WEB-INF/views/dashboard/manager.jsp").forward(request, response);
        } else if (user.isTeamLead()) {
            // Team Lead dashboard - plans awaiting review, team performance
            List<Plan> pendingPlans = planDAO.findByStatus("Pending");
            List<Plan> allPlans = planDAO.findByDateRange(startDate, endDate);
            List<Approval> recentApprovals = approvalDAO.findByApproverId(user.getId());
            
            // Get team members (all employees)
            List<User> teamMembers = userDAO.findByRole("SDE");
            teamMembers.addAll(userDAO.findByRole("JSDE"));
            teamMembers.addAll(userDAO.findByRole("Intern"));
            
            request.setAttribute("pendingPlans", pendingPlans);
            request.setAttribute("allPlans", allPlans);
            request.setAttribute("recentApprovals", recentApprovals);
            request.setAttribute("teamMembers", teamMembers);
            
            // Count plans by status
            int pendingCount = 0;
            int approvedCount = 0;
            int rejectedCount = 0;
            int reworkCount = 0;
            
            for (Plan plan : allPlans) {
                if (plan.isPending()) pendingCount++;
                else if (plan.isApproved()) approvedCount++;
                else if (plan.isRejected()) rejectedCount++;
                else if (plan.needsRework()) reworkCount++;
            }
            
            request.setAttribute("pendingCount", pendingCount);
            request.setAttribute("approvedCount", approvedCount);
            request.setAttribute("rejectedCount", rejectedCount);
            request.setAttribute("reworkCount", reworkCount);
            
            request.getRequestDispatcher("/WEB-INF/views/dashboard/teamlead.jsp").forward(request, response);
        } else {
            // Employee dashboard - plan status, create new plans
            List<Plan> userPlans = planDAO.findByUserId(user.getId());
            List<WorkLog> userWorkLogs = workLogDAO.findByUserIdAndDateRange(user.getId(), startDate, endDate);
            
            request.setAttribute("plans", userPlans);
            request.setAttribute("workLogs", userWorkLogs);
            
            // Count plans by status
            int pendingCount = 0;
            int approvedCount = 0;
            int rejectedCount = 0;
            int reworkCount = 0;
            
            for (Plan plan : userPlans) {
                if (plan.isPending()) pendingCount++;
                else if (plan.isApproved()) approvedCount++;
                else if (plan.isRejected()) rejectedCount++;
                else if (plan.needsRework()) reworkCount++;
            }
            
            request.setAttribute("pendingCount", pendingCount);
            request.setAttribute("approvedCount", approvedCount);
            request.setAttribute("rejectedCount", rejectedCount);
            request.setAttribute("reworkCount", reworkCount);
            
            // Calculate total hours
            float totalEstimatedHours = 0;
            float totalActualHours = 0;
            float totalOverflowHours = 0;
            
            for (Plan plan : userPlans) {
                totalEstimatedHours += plan.getTotalEstimatedTime();
                totalActualHours += plan.getTotalActualTime();
                totalOverflowHours += plan.getTotalOverflowHours();
            }
            
            request.setAttribute("totalEstimatedHours", totalEstimatedHours);
            request.setAttribute("totalActualHours", totalActualHours);
            request.setAttribute("totalOverflowHours", totalOverflowHours);
            
            request.getRequestDispatcher("/WEB-INF/views/dashboard/employee.jsp").forward(request, response);
        }
    }
}
