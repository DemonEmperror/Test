package com.poa.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.poa.dao.ApprovalDAO;
import com.poa.dao.PlanDAO;
import com.poa.dao.UserDAO;
import com.poa.dao.WorkLogDAO;
import com.poa.model.User;
import com.poa.util.SecurityUtil;

public class AdminController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO = new UserDAO();
    private PlanDAO planDAO = new PlanDAO();
    private WorkLogDAO workLogDAO = new WorkLogDAO();
    private ApprovalDAO approvalDAO = new ApprovalDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        if (!SecurityUtil.isLoggedIn(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Check if user is admin
        User user = SecurityUtil.getLoggedInUser(request);
        if (!user.isAdmin()) {
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        String path = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        // Generate CSRF token
        String csrfToken = SecurityUtil.generateCSRFToken(request);
        request.setAttribute("csrfToken", csrfToken);
        
        switch (path) {
            case "/admin":
                // Admin dashboard
                request.getRequestDispatcher("/WEB-INF/views/admin/dashboard.jsp").forward(request, response);
                break;
                
            case "/admin/users":
                // List all users
                List<User> users = userDAO.findAll();
                request.setAttribute("users", users);
                request.getRequestDispatcher("/WEB-INF/views/admin/users/list.jsp").forward(request, response);
                break;
                
            case "/admin/users/create":
                // Create user form
                request.getRequestDispatcher("/WEB-INF/views/admin/users/create.jsp").forward(request, response);
                break;
                
            case "/admin/users/edit":
                // Edit user form
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
                
                int userId = Integer.parseInt(pathInfo.substring(1));
                User targetUser = userDAO.findById(userId);
                
                if (targetUser == null) {
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
                
                request.setAttribute("user", targetUser);
                request.getRequestDispatcher("/WEB-INF/views/admin/users/edit.jsp").forward(request, response);
                break;
                
            case "/admin/users/delete":
                // Delete user confirmation
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
                
                userId = Integer.parseInt(pathInfo.substring(1));
                targetUser = userDAO.findById(userId);
                
                if (targetUser == null) {
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
                
                // Cannot delete yourself
                if (targetUser.getId() == user.getId()) {
                    request.getSession().setAttribute("error", "You cannot delete your own account.");
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
                
                request.setAttribute("user", targetUser);
                request.getRequestDispatcher("/WEB-INF/views/admin/users/delete.jsp").forward(request, response);
                break;
                
            case "/admin/system":
                // System settings
                request.getRequestDispatcher("/WEB-INF/views/admin/system.jsp").forward(request, response);
                break;
                
            default:
                response.sendRedirect(request.getContextPath() + "/admin");
                break;
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        if (!SecurityUtil.isLoggedIn(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Check if user is admin
        User user = SecurityUtil.getLoggedInUser(request);
        if (!user.isAdmin()) {
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        // Validate CSRF token
        if (!SecurityUtil.validateCSRFToken(request)) {
            request.getSession().setAttribute("error", "Invalid request. Please try again.");
            response.sendRedirect(request.getContextPath() + "/admin");
            return;
        }
        
        String path = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        switch (path) {
            case "/admin/users/create":
                // Create new user
                String username = request.getParameter("username");
                String password = request.getParameter("password");
                String confirmPassword = request.getParameter("confirmPassword");
                String firstName = request.getParameter("firstName");
                String lastName = request.getParameter("lastName");
                String email = request.getParameter("email");
                String role = request.getParameter("role");
                
                // Validate form data
                if (username == null || username.trim().isEmpty() ||
                    password == null || password.trim().isEmpty() ||
                    confirmPassword == null || confirmPassword.trim().isEmpty() ||
                    firstName == null || firstName.trim().isEmpty() ||
                    lastName == null || lastName.trim().isEmpty() ||
                    email == null || email.trim().isEmpty() ||
                    role == null || role.trim().isEmpty()) {
                    
                    request.setAttribute("error", "All fields are required.");
                    request.getRequestDispatcher("/WEB-INF/views/admin/users/create.jsp").forward(request, response);
                    return;
                }
                
                // Check if passwords match
                if (!password.equals(confirmPassword)) {
                    request.setAttribute("error", "Passwords do not match.");
                    request.getRequestDispatcher("/WEB-INF/views/admin/users/create.jsp").forward(request, response);
                    return;
                }
                
                // Check if username already exists
                if (userDAO.findByUsername(username) != null) {
                    request.setAttribute("error", "Username already exists.");
                    request.getRequestDispatcher("/WEB-INF/views/admin/users/create.jsp").forward(request, response);
                    return;
                }
                
                // Create new user
                User newUser = new User();
                newUser.setUsername(username);
                newUser.setPassword(SecurityUtil.hashPassword(password));
                newUser.setFirstName(firstName);
                newUser.setLastName(lastName);
                newUser.setEmail(email);
                newUser.setRole(role);
                
                User createdUser = userDAO.create(newUser);
                
                if (createdUser == null) {
                    request.setAttribute("error", "Failed to create user. Please try again.");
                    request.getRequestDispatcher("/WEB-INF/views/admin/users/create.jsp").forward(request, response);
                    return;
                }
                
                // Set success message and redirect to users list
                request.getSession().setAttribute("success", "User created successfully.");
                response.sendRedirect(request.getContextPath() + "/admin/users");
                break;
                
            case "/admin/users/edit":
                // Edit user
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
                
                int userId = Integer.parseInt(pathInfo.substring(1));
                User existingUser = userDAO.findById(userId);
                
                if (existingUser == null) {
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
                
                // Get form data
                username = request.getParameter("username");
                password = request.getParameter("password");
                confirmPassword = request.getParameter("confirmPassword");
                firstName = request.getParameter("firstName");
                lastName = request.getParameter("lastName");
                email = request.getParameter("email");
                role = request.getParameter("role");
                
                // Validate form data
                if (username == null || username.trim().isEmpty() ||
                    firstName == null || firstName.trim().isEmpty() ||
                    lastName == null || lastName.trim().isEmpty() ||
                    email == null || email.trim().isEmpty() ||
                    role == null || role.trim().isEmpty()) {
                    
                    request.setAttribute("error", "All fields except password are required.");
                    request.setAttribute("user", existingUser);
                    request.getRequestDispatcher("/WEB-INF/views/admin/users/edit.jsp").forward(request, response);
                    return;
                }
                
                // Check if username already exists (for another user)
                User userWithSameUsername = userDAO.findByUsername(username);
                if (userWithSameUsername != null && userWithSameUsername.getId() != userId) {
                    request.setAttribute("error", "Username already exists.");
                    request.setAttribute("user", existingUser);
                    request.getRequestDispatcher("/WEB-INF/views/admin/users/edit.jsp").forward(request, response);
                    return;
                }
                
                // Update user
                existingUser.setUsername(username);
                existingUser.setFirstName(firstName);
                existingUser.setLastName(lastName);
                existingUser.setEmail(email);
                existingUser.setRole(role);
                
                // Update password if provided
                if (password != null && !password.trim().isEmpty()) {
                    // Check if passwords match
                    if (!password.equals(confirmPassword)) {
                        request.setAttribute("error", "Passwords do not match.");
                        request.setAttribute("user", existingUser);
                        request.getRequestDispatcher("/WEB-INF/views/admin/users/edit.jsp").forward(request, response);
                        return;
                    }
                    
                    existingUser.setPassword(SecurityUtil.hashPassword(password));
                }
                
                boolean updated = userDAO.update(existingUser);
                
                if (!updated) {
                    request.setAttribute("error", "Failed to update user. Please try again.");
                    request.setAttribute("user", existingUser);
                    request.getRequestDispatcher("/WEB-INF/views/admin/users/edit.jsp").forward(request, response);
                    return;
                }
                
                // Set success message and redirect to users list
                request.getSession().setAttribute("success", "User updated successfully.");
                response.sendRedirect(request.getContextPath() + "/admin/users");
                break;
                
            case "/admin/users/delete":
                // Delete user
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
                
                userId = Integer.parseInt(pathInfo.substring(1));
                existingUser = userDAO.findById(userId);
                
                if (existingUser == null) {
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
                
                // Cannot delete yourself
                if (existingUser.getId() == user.getId()) {
                    request.getSession().setAttribute("error", "You cannot delete your own account.");
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
                
                // Delete user
                boolean deleted = userDAO.delete(userId);
                
                if (!deleted) {
                    request.getSession().setAttribute("error", "Failed to delete user. Please try again.");
                    response.sendRedirect(request.getContextPath() + "/admin/users");
                    return;
                }
                
                // Set success message and redirect to users list
                request.getSession().setAttribute("success", "User deleted successfully.");
                response.sendRedirect(request.getContextPath() + "/admin/users");
                break;
                
            case "/admin/system":
                // Update system settings
                String action = request.getParameter("action");
                
                if ("clearData".equals(action)) {
                    // Clear all data (except users)
                    boolean clearedApprovals = approvalDAO.deleteAll();
                    boolean clearedWorkLogs = workLogDAO.deleteAll();
                    boolean clearedPlans = planDAO.deleteAll();
                    
                    if (clearedApprovals && clearedWorkLogs && clearedPlans) {
                        request.getSession().setAttribute("success", "All data has been cleared successfully.");
                    } else {
                        request.getSession().setAttribute("error", "Failed to clear all data. Please try again.");
                    }
                }
                
                response.sendRedirect(request.getContextPath() + "/admin/system");
                break;
                
            default:
                response.sendRedirect(request.getContextPath() + "/admin");
                break;
        }
    }
}
