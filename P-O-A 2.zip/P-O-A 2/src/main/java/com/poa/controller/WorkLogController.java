package com.poa.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.poa.dao.PlanDAO;
import com.poa.dao.WorkLogDAO;
import com.poa.model.Plan;
import com.poa.model.User;
import com.poa.model.WorkLog;
import com.poa.util.DateUtil;
import com.poa.util.SecurityUtil;

public class WorkLogController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private WorkLogDAO workLogDAO = new WorkLogDAO();
    private PlanDAO planDAO = new PlanDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        if (!SecurityUtil.isLoggedIn(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String path = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        // Get logged in user
        User user = SecurityUtil.getLoggedInUser(request);
        
        // Generate CSRF token
        String csrfToken = SecurityUtil.generateCSRFToken(request);
        request.setAttribute("csrfToken", csrfToken);
        
        switch (path) {
            case "/worklogs":
                // List all work logs
                if (user.isEmployee()) {
                    // Employees can only see their own work logs
                    List<WorkLog> workLogs = workLogDAO.findByUserId(user.getId());
                    request.setAttribute("workLogs", workLogs);
                } else {
                    // Managers, Team Leads, and Admins can see all work logs
                    List<WorkLog> workLogs = workLogDAO.findAll();
                    request.setAttribute("workLogs", workLogs);
                }
                
                request.getRequestDispatcher("/WEB-INF/views/worklogs/list.jsp").forward(request, response);
                break;
                
            case "/worklogs/create":
                // Only employees can create work logs
                if (!user.isEmployee() && !user.isAdmin()) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                // Set today's date as default
                request.setAttribute("today", DateUtil.formatDate(DateUtil.getCurrentDate()));
                
                // Get user's plans for selection
                List<Plan> userPlans = planDAO.findByUserId(user.getId());
                request.setAttribute("plans", userPlans);
                
                request.getRequestDispatcher("/WEB-INF/views/worklogs/create.jsp").forward(request, response);
                break;
                
            case "/worklogs/edit":
                // Edit work log
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                int workLogId = Integer.parseInt(pathInfo.substring(1));
                WorkLog workLog = workLogDAO.findById(workLogId);
                
                if (workLog == null) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                // Check if user is authorized to edit this work log
                if (user.isEmployee() && workLog.getUserId() != user.getId()) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                // Get user's plans for selection
                userPlans = planDAO.findByUserId(workLog.getUserId());
                request.setAttribute("plans", userPlans);
                
                request.setAttribute("workLog", workLog);
                request.getRequestDispatcher("/WEB-INF/views/worklogs/edit.jsp").forward(request, response);
                break;
                
            case "/worklogs/view":
                // View work log details
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                workLogId = Integer.parseInt(pathInfo.substring(1));
                workLog = workLogDAO.findById(workLogId);
                
                if (workLog == null) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                // Check if user is authorized to view this work log
                if (user.isEmployee() && workLog.getUserId() != user.getId()) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                request.setAttribute("workLog", workLog);
                request.getRequestDispatcher("/WEB-INF/views/worklogs/view.jsp").forward(request, response);
                break;
                
            case "/worklogs/delete":
                // Delete work log
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                workLogId = Integer.parseInt(pathInfo.substring(1));
                workLog = workLogDAO.findById(workLogId);
                
                if (workLog == null) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                // Check if user is authorized to delete this work log
                if (user.isEmployee() && workLog.getUserId() != user.getId()) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                request.setAttribute("workLog", workLog);
                request.getRequestDispatcher("/WEB-INF/views/worklogs/delete.jsp").forward(request, response);
                break;
                
            default:
                response.sendRedirect(request.getContextPath() + "/worklogs");
                break;
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        if (!SecurityUtil.isLoggedIn(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Validate CSRF token
        if (!SecurityUtil.validateCSRFToken(request)) {
            request.getSession().setAttribute("error", "Invalid request. Please try again.");
            response.sendRedirect(request.getContextPath() + "/worklogs");
            return;
        }
        
        String path = request.getServletPath();
        String pathInfo = request.getPathInfo();
        
        // Get logged in user
        User user = SecurityUtil.getLoggedInUser(request);
        
        switch (path) {
            case "/worklogs/create":
                // Create new work log
                
                // Only employees can create work logs
                if (!user.isEmployee() && !user.isAdmin()) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                // Get form data
                String dateStr = request.getParameter("date");
                String planIdStr = request.getParameter("planId");
                String actualTimeStr = request.getParameter("actualTime");
                String unplannedWork = request.getParameter("unplannedWork");
                
                // Validate form data
                if (dateStr == null || dateStr.trim().isEmpty() || 
                    actualTimeStr == null || actualTimeStr.trim().isEmpty()) {
                    
                    request.setAttribute("error", "Date and actual time are required.");
                    request.setAttribute("today", DateUtil.formatDate(DateUtil.getCurrentDate()));
                    
                    // Get user's plans for selection
                    List<Plan> userPlans = planDAO.findByUserId(user.getId());
                    request.setAttribute("plans", userPlans);
                    
                    request.getRequestDispatcher("/WEB-INF/views/worklogs/create.jsp").forward(request, response);
                    return;
                }
                
                // Create new work log
                WorkLog workLog = new WorkLog();
                workLog.setUserId(user.getId());
                workLog.setDate(DateUtil.parseDate(dateStr));
                
                // Set plan ID if provided
                if (planIdStr != null && !planIdStr.trim().isEmpty() && !planIdStr.equals("0")) {
                    workLog.setPlanId(Integer.parseInt(planIdStr.trim()));
                }
                
                workLog.setActualTime(Float.parseFloat(actualTimeStr.trim()));
                workLog.setUnplannedWork(unplannedWork);
                
                // Save work log to database
                WorkLog createdWorkLog = workLogDAO.create(workLog);
                
                if (createdWorkLog == null) {
                    request.setAttribute("error", "Failed to create work log. Please try again.");
                    request.setAttribute("today", DateUtil.formatDate(DateUtil.getCurrentDate()));
                    
                    // Get user's plans for selection
                    List<Plan> userPlans = planDAO.findByUserId(user.getId());
                    request.setAttribute("plans", userPlans);
                    
                    request.getRequestDispatcher("/WEB-INF/views/worklogs/create.jsp").forward(request, response);
                    return;
                }
                
                // Set success message and redirect to work log view
                request.getSession().setAttribute("success", "Work log created successfully.");
                response.sendRedirect(request.getContextPath() + "/worklogs/view/" + createdWorkLog.getId());
                break;
                
            case "/worklogs/edit":
                // Edit work log
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                int workLogId = Integer.parseInt(pathInfo.substring(1));
                WorkLog existingWorkLog = workLogDAO.findById(workLogId);
                
                if (existingWorkLog == null) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                // Check if user is authorized to edit this work log
                if (user.isEmployee() && existingWorkLog.getUserId() != user.getId()) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                // Get form data
                dateStr = request.getParameter("date");
                planIdStr = request.getParameter("planId");
                actualTimeStr = request.getParameter("actualTime");
                unplannedWork = request.getParameter("unplannedWork");
                
                // Validate form data
                if (dateStr == null || dateStr.trim().isEmpty() || 
                    actualTimeStr == null || actualTimeStr.trim().isEmpty()) {
                    
                    request.setAttribute("error", "Date and actual time are required.");
                    request.setAttribute("workLog", existingWorkLog);
                    
                    // Get user's plans for selection
                    List<Plan> userPlans = planDAO.findByUserId(existingWorkLog.getUserId());
                    request.setAttribute("plans", userPlans);
                    
                    request.getRequestDispatcher("/WEB-INF/views/worklogs/edit.jsp").forward(request, response);
                    return;
                }
                
                // Update work log
                existingWorkLog.setDate(DateUtil.parseDate(dateStr));
                
                // Set plan ID if provided
                if (planIdStr != null && !planIdStr.trim().isEmpty() && !planIdStr.equals("0")) {
                    existingWorkLog.setPlanId(Integer.parseInt(planIdStr.trim()));
                } else {
                    existingWorkLog.setPlanId(null);
                }
                
                existingWorkLog.setActualTime(Float.parseFloat(actualTimeStr.trim()));
                existingWorkLog.setUnplannedWork(unplannedWork);
                
                // Save work log to database
                boolean updated = workLogDAO.update(existingWorkLog);
                
                if (!updated) {
                    request.setAttribute("error", "Failed to update work log. Please try again.");
                    request.setAttribute("workLog", existingWorkLog);
                    
                    // Get user's plans for selection
                    List<Plan> userPlans = planDAO.findByUserId(existingWorkLog.getUserId());
                    request.setAttribute("plans", userPlans);
                    
                    request.getRequestDispatcher("/WEB-INF/views/worklogs/edit.jsp").forward(request, response);
                    return;
                }
                
                // Set success message and redirect to work log view
                request.getSession().setAttribute("success", "Work log updated successfully.");
                response.sendRedirect(request.getContextPath() + "/worklogs/view/" + workLogId);
                break;
                
            case "/worklogs/delete":
                // Delete work log
                if (pathInfo == null || pathInfo.equals("/")) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                workLogId = Integer.parseInt(pathInfo.substring(1));
                existingWorkLog = workLogDAO.findById(workLogId);
                
                if (existingWorkLog == null) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                // Check if user is authorized to delete this work log
                if (user.isEmployee() && existingWorkLog.getUserId() != user.getId()) {
                    response.sendRedirect(request.getContextPath() + "/worklogs");
                    return;
                }
                
                // Delete work log
                boolean deleted = workLogDAO.delete(workLogId);
                
                if (!deleted) {
                    request.getSession().setAttribute("error", "Failed to delete work log. Please try again.");
                    response.sendRedirect(request.getContextPath() + "/worklogs/view/" + workLogId);
                    return;
                }
                
                // Set success message and redirect to work logs list
                request.getSession().setAttribute("success", "Work log deleted successfully.");
                response.sendRedirect(request.getContextPath() + "/worklogs");
                break;
                
            default:
                response.sendRedirect(request.getContextPath() + "/worklogs");
                break;
        }
    }
}
