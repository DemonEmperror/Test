package com.poa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.poa.model.Approval;
import com.poa.model.User;
import com.poa.util.DBConnectionUtil;

public class ApprovalDAO {
    private static final Logger LOGGER = Logger.getLogger(ApprovalDAO.class.getName());
    private final UserDAO userDAO = new UserDAO();
    
    // Create a new approval
    public Approval create(Approval approval) {
        String sql = "INSERT INTO approvals (plan_id, approved_by, role, status, comments) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, approval.getPlanId());
            stmt.setInt(2, approval.getApprovedBy());
            stmt.setString(3, approval.getRole());
            stmt.setString(4, approval.getStatus());
            stmt.setString(5, approval.getComments());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating approval failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    approval.setId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating approval failed, no ID obtained.");
                }
            }
            
            return approval;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error creating approval", e);
            return null;
        }
    }
    
    // Get approval by ID
    public Approval findById(int id) {
        String sql = "SELECT a.*, u.name as approver_name, u.email as approver_email, u.role as approver_role " +
                     "FROM approvals a " +
                     "JOIN users u ON a.approved_by = u.id " +
                     "WHERE a.id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToApproval(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding approval by ID: " + id, e);
        }
        
        return null;
    }
    
    // Get approvals by plan ID
    public List<Approval> findByPlanId(int planId) {
        String sql = "SELECT a.*, u.name as approver_name, u.email as approver_email, u.role as approver_role " +
                     "FROM approvals a " +
                     "JOIN users u ON a.approved_by = u.id " +
                     "WHERE a.plan_id = ? " +
                     "ORDER BY a.timestamp DESC";
        
        List<Approval> approvals = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, planId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    approvals.add(mapResultSetToApproval(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding approvals by plan ID: " + planId, e);
        }
        
        return approvals;
    }
    
    // Get approvals by approver ID
    public List<Approval> findByApproverId(int approverId) {
        String sql = "SELECT a.*, u.name as approver_name, u.email as approver_email, u.role as approver_role " +
                     "FROM approvals a " +
                     "JOIN users u ON a.approved_by = u.id " +
                     "WHERE a.approved_by = ? " +
                     "ORDER BY a.timestamp DESC";
        
        List<Approval> approvals = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, approverId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    approvals.add(mapResultSetToApproval(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding approvals by approver ID: " + approverId, e);
        }
        
        return approvals;
    }
    
    // Get approvals by status
    public List<Approval> findByStatus(String status) {
        String sql = "SELECT a.*, u.name as approver_name, u.email as approver_email, u.role as approver_role " +
                     "FROM approvals a " +
                     "JOIN users u ON a.approved_by = u.id " +
                     "WHERE a.status = ? " +
                     "ORDER BY a.timestamp DESC";
        
        List<Approval> approvals = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    approvals.add(mapResultSetToApproval(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding approvals by status: " + status, e);
        }
        
        return approvals;
    }
    
    // Get approvals by role
    public List<Approval> findByRole(String role) {
        String sql = "SELECT a.*, u.name as approver_name, u.email as approver_email, u.role as approver_role " +
                     "FROM approvals a " +
                     "JOIN users u ON a.approved_by = u.id " +
                     "WHERE a.role = ? " +
                     "ORDER BY a.timestamp DESC";
        
        List<Approval> approvals = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, role);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    approvals.add(mapResultSetToApproval(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding approvals by role: " + role, e);
        }
        
        return approvals;
    }
    
    // Get all approvals
    public List<Approval> findAll() {
        String sql = "SELECT a.*, u.name as approver_name, u.email as approver_email, u.role as approver_role " +
                     "FROM approvals a " +
                     "JOIN users u ON a.approved_by = u.id " +
                     "ORDER BY a.timestamp DESC";
        
        List<Approval> approvals = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                approvals.add(mapResultSetToApproval(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding all approvals", e);
        }
        
        return approvals;
    }
    
    // Delete all approvals
    public boolean deleteAll() {
        String sql = "DELETE FROM approvals";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            
            int affectedRows = stmt.executeUpdate(sql);
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting all approvals", e);
            return false;
        }
    }
    
    // Update approval
    public boolean update(Approval approval) {
        String sql = "UPDATE approvals SET plan_id = ?, approved_by = ?, role = ?, status = ?, comments = ? WHERE id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, approval.getPlanId());
            stmt.setInt(2, approval.getApprovedBy());
            stmt.setString(3, approval.getRole());
            stmt.setString(4, approval.getStatus());
            stmt.setString(5, approval.getComments());
            stmt.setInt(6, approval.getId());
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error updating approval: " + approval.getId(), e);
            return false;
        }
    }
    
    // Delete approval
    public boolean delete(int id) {
        String sql = "DELETE FROM approvals WHERE id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting approval: " + id, e);
            return false;
        }
    }
    
    // Delete all approvals for a plan
    public boolean deleteByPlanId(int planId) {
        String sql = "DELETE FROM approvals WHERE plan_id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, planId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting approvals by plan ID: " + planId, e);
            return false;
        }
    }
    
    // Helper method to map ResultSet to Approval object
    private Approval mapResultSetToApproval(ResultSet rs) throws SQLException {
        Approval approval = new Approval();
        approval.setId(rs.getInt("id"));
        approval.setPlanId(rs.getInt("plan_id"));
        approval.setApprovedBy(rs.getInt("approved_by"));
        approval.setRole(rs.getString("role"));
        approval.setStatus(rs.getString("status"));
        approval.setComments(rs.getString("comments"));
        approval.setTimestamp(rs.getTimestamp("timestamp"));
        
        // Create and set approver
        User approver = new User();
        approver.setId(rs.getInt("approved_by"));
        approver.setName(rs.getString("approver_name"));
        approver.setEmail(rs.getString("approver_email"));
        approver.setRole(rs.getString("approver_role"));
        approval.setApprover(approver);
        
        return approval;
    }
}
