package com.poa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.poa.model.PlanDeliverable;
import com.poa.util.DBConnectionUtil;

public class PlanDeliverableDAO {
    private static final Logger LOGGER = Logger.getLogger(PlanDeliverableDAO.class.getName());
    
    // Create a new plan deliverable
    public PlanDeliverable create(PlanDeliverable deliverable) {
        Connection conn = null;
        try {
            conn = DBConnectionUtil.getConnection();
            return create(deliverable, conn);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting connection", e);
            return null;
        } finally {
            DBConnectionUtil.closeConnection(conn);
        }
    }
    
    // Create a new plan deliverable with existing connection
    public PlanDeliverable create(PlanDeliverable deliverable, Connection conn) {
        String sql = "INSERT INTO plan_deliverables (plan_id, description, estimated_time, actual_time, overflow_hours, rework, achieved) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, deliverable.getPlanId());
            stmt.setString(2, deliverable.getDescription());
            stmt.setFloat(3, deliverable.getEstimatedTime());
            stmt.setFloat(4, deliverable.getActualTime());
            stmt.setFloat(5, deliverable.getOverflowHours());
            stmt.setBoolean(6, deliverable.isRework());
            stmt.setBoolean(7, deliverable.isAchieved());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating plan deliverable failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    deliverable.setId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating plan deliverable failed, no ID obtained.");
                }
            }
            
            return deliverable;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error creating plan deliverable", e);
            return null;
        }
    }
    
    // Get plan deliverable by ID
    public PlanDeliverable findById(int id) {
        String sql = "SELECT * FROM plan_deliverables WHERE id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToDeliverable(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding plan deliverable by ID: " + id, e);
        }
        
        return null;
    }
    
    // Get plan deliverables by plan ID
    public List<PlanDeliverable> findByPlanId(int planId) {
        String sql = "SELECT * FROM plan_deliverables WHERE plan_id = ?";
        List<PlanDeliverable> deliverables = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, planId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    deliverables.add(mapResultSetToDeliverable(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding plan deliverables by plan ID: " + planId, e);
        }
        
        return deliverables;
    }
    
    // Update plan deliverable
    public boolean update(PlanDeliverable deliverable) {
        Connection conn = null;
        try {
            conn = DBConnectionUtil.getConnection();
            return update(deliverable, conn);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting connection", e);
            return false;
        } finally {
            DBConnectionUtil.closeConnection(conn);
        }
    }
    
    // Update plan deliverable with existing connection
    public boolean update(PlanDeliverable deliverable, Connection conn) {
        String sql = "UPDATE plan_deliverables SET description = ?, estimated_time = ?, actual_time = ?, " +
                     "overflow_hours = ?, rework = ?, achieved = ? WHERE id = ?";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, deliverable.getDescription());
            stmt.setFloat(2, deliverable.getEstimatedTime());
            stmt.setFloat(3, deliverable.getActualTime());
            stmt.setFloat(4, deliverable.getOverflowHours());
            stmt.setBoolean(5, deliverable.isRework());
            stmt.setBoolean(6, deliverable.isAchieved());
            stmt.setInt(7, deliverable.getId());
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error updating plan deliverable: " + deliverable.getId(), e);
            return false;
        }
    }
    
    // Delete plan deliverable
    public boolean delete(int id) {
        String sql = "DELETE FROM plan_deliverables WHERE id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting plan deliverable: " + id, e);
            return false;
        }
    }
    
    // Delete all deliverables for a plan
    public boolean deleteByPlanId(int planId) {
        String sql = "DELETE FROM plan_deliverables WHERE plan_id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, planId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting plan deliverables by plan ID: " + planId, e);
            return false;
        }
    }
    
    // Helper method to map ResultSet to PlanDeliverable object
    private PlanDeliverable mapResultSetToDeliverable(ResultSet rs) throws SQLException {
        PlanDeliverable deliverable = new PlanDeliverable();
        deliverable.setId(rs.getInt("id"));
        deliverable.setPlanId(rs.getInt("plan_id"));
        deliverable.setDescription(rs.getString("description"));
        deliverable.setEstimatedTime(rs.getFloat("estimated_time"));
        deliverable.setActualTime(rs.getFloat("actual_time"));
        deliverable.setOverflowHours(rs.getFloat("overflow_hours"));
        deliverable.setRework(rs.getBoolean("rework"));
        deliverable.setAchieved(rs.getBoolean("achieved"));
        deliverable.setCreatedAt(rs.getTimestamp("created_at"));
        deliverable.setUpdatedAt(rs.getTimestamp("updated_at"));
        return deliverable;
    }
}
