package com.poa.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.poa.model.User;
import com.poa.model.WorkLog;
import com.poa.util.DBConnectionUtil;

public class WorkLogDAO {
    private static final Logger LOGGER = Logger.getLogger(WorkLogDAO.class.getName());
    private final UserDAO userDAO = new UserDAO();
    
    // Create a new work log
    public WorkLog create(WorkLog workLog) {
        String sql = "INSERT INTO work_logs (user_id, date, plan_id, actual_time, unplanned_work) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, workLog.getUserId());
            stmt.setDate(2, workLog.getDate());
            
            if (workLog.getPlanId() != null) {
                stmt.setInt(3, workLog.getPlanId());
            } else {
                stmt.setNull(3, java.sql.Types.INTEGER);
            }
            
            stmt.setFloat(4, workLog.getActualTime());
            stmt.setString(5, workLog.getUnplannedWork());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows == 0) {
                throw new SQLException("Creating work log failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    workLog.setId(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Creating work log failed, no ID obtained.");
                }
            }
            
            return workLog;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error creating work log", e);
            return null;
        }
    }
    
    // Get work log by ID
    public WorkLog findById(int id) {
        String sql = "SELECT w.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM work_logs w " +
                     "JOIN users u ON w.user_id = u.id " +
                     "WHERE w.id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToWorkLog(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding work log by ID: " + id, e);
        }
        
        return null;
    }
    
    // Get work logs by user ID
    public List<WorkLog> findByUserId(int userId) {
        String sql = "SELECT w.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM work_logs w " +
                     "JOIN users u ON w.user_id = u.id " +
                     "WHERE w.user_id = ? " +
                     "ORDER BY w.date DESC";
        
        return findWorkLogsByQuery(sql, userId);
    }
    
    // Get work logs by date
    public List<WorkLog> findByDate(Date date) {
        String sql = "SELECT w.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM work_logs w " +
                     "JOIN users u ON w.user_id = u.id " +
                     "WHERE w.date = ? " +
                     "ORDER BY w.user_id";
        
        return findWorkLogsByQuery(sql, date);
    }
    
    // Get work logs by plan ID
    public List<WorkLog> findByPlanId(int planId) {
        String sql = "SELECT w.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM work_logs w " +
                     "JOIN users u ON w.user_id = u.id " +
                     "WHERE w.plan_id = ? " +
                     "ORDER BY w.date DESC";
        
        return findWorkLogsByQuery(sql, planId);
    }
    
    // Get work logs by date range
    public List<WorkLog> findByDateRange(Date startDate, Date endDate) {
        String sql = "SELECT w.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM work_logs w " +
                     "JOIN users u ON w.user_id = u.id " +
                     "WHERE w.date BETWEEN ? AND ? " +
                     "ORDER BY w.date DESC, w.user_id";
        
        List<WorkLog> workLogs = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setDate(1, startDate);
            stmt.setDate(2, endDate);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    workLogs.add(mapResultSetToWorkLog(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding work logs by date range", e);
        }
        
        return workLogs;
    }
    
    // Get work logs by user ID and date range
    public List<WorkLog> findByUserIdAndDateRange(int userId, Date startDate, Date endDate) {
        String sql = "SELECT w.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM work_logs w " +
                     "JOIN users u ON w.user_id = u.id " +
                     "WHERE w.user_id = ? AND w.date BETWEEN ? AND ? " +
                     "ORDER BY w.date DESC";
        
        List<WorkLog> workLogs = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            stmt.setDate(2, startDate);
            stmt.setDate(3, endDate);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    workLogs.add(mapResultSetToWorkLog(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding work logs by user ID and date range", e);
        }
        
        return workLogs;
    }
    
    // Get all work logs
    public List<WorkLog> findAll() {
        String sql = "SELECT w.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM work_logs w " +
                     "JOIN users u ON w.user_id = u.id " +
                     "ORDER BY w.date DESC";
        
        List<WorkLog> workLogs = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                workLogs.add(mapResultSetToWorkLog(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding all work logs", e);
        }
        
        return workLogs;
    }
    
    // Delete all work logs
    public boolean deleteAll() {
        String sql = "DELETE FROM work_logs";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            
            int affectedRows = stmt.executeUpdate(sql);
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting all work logs", e);
            return false;
        }
    }
    
    // Update work log
    public boolean update(WorkLog workLog) {
        String sql = "UPDATE work_logs SET user_id = ?, date = ?, plan_id = ?, actual_time = ?, unplanned_work = ? WHERE id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, workLog.getUserId());
            stmt.setDate(2, workLog.getDate());
            
            if (workLog.getPlanId() != null) {
                stmt.setInt(3, workLog.getPlanId());
            } else {
                stmt.setNull(3, java.sql.Types.INTEGER);
            }
            
            stmt.setFloat(4, workLog.getActualTime());
            stmt.setString(5, workLog.getUnplannedWork());
            stmt.setInt(6, workLog.getId());
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error updating work log: " + workLog.getId(), e);
            return false;
        }
    }
    
    // Delete work log
    public boolean delete(int id) {
        String sql = "DELETE FROM work_logs WHERE id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting work log: " + id, e);
            return false;
        }
    }
    
    // Helper method to find work logs by a parameterized query
    private List<WorkLog> findWorkLogsByQuery(String sql, Object param) {
        List<WorkLog> workLogs = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            if (param instanceof Integer) {
                stmt.setInt(1, (Integer) param);
            } else if (param instanceof Date) {
                stmt.setDate(1, (Date) param);
            } else if (param instanceof String) {
                stmt.setString(1, (String) param);
            }
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    workLogs.add(mapResultSetToWorkLog(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error executing query: " + sql, e);
        }
        
        return workLogs;
    }
    
    // Helper method to map ResultSet to WorkLog object
    private WorkLog mapResultSetToWorkLog(ResultSet rs) throws SQLException {
        WorkLog workLog = new WorkLog();
        workLog.setId(rs.getInt("id"));
        workLog.setUserId(rs.getInt("user_id"));
        workLog.setDate(rs.getDate("date"));
        
        int planId = rs.getInt("plan_id");
        if (!rs.wasNull()) {
            workLog.setPlanId(planId);
        }
        
        workLog.setActualTime(rs.getFloat("actual_time"));
        workLog.setUnplannedWork(rs.getString("unplanned_work"));
        workLog.setCreatedAt(rs.getTimestamp("created_at"));
        workLog.setUpdatedAt(rs.getTimestamp("updated_at"));
        
        // Create and set user
        User user = new User();
        user.setId(rs.getInt("user_id"));
        user.setName(rs.getString("user_name"));
        user.setEmail(rs.getString("user_email"));
        user.setRole(rs.getString("user_role"));
        workLog.setUser(user);
        
        return workLog;
    }
}
