package com.poa.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.poa.model.Plan;
import com.poa.model.User;
import com.poa.util.DBConnectionUtil;

public class PlanDAO {
    private static final Logger LOGGER = Logger.getLogger(PlanDAO.class.getName());
    private final UserDAO userDAO = new UserDAO();
    
    // Create a new plan
    public Plan create(Plan plan) {
        String sql = "INSERT INTO plans (user_id, date, status) VALUES (?, ?, ?)";
        Connection conn = null;
        
        try {
            conn = DBConnectionUtil.getConnection();
            conn.setAutoCommit(false);
            
            try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, plan.getUserId());
                stmt.setDate(2, plan.getDate());
                stmt.setString(3, plan.getStatus());
                
                int affectedRows = stmt.executeUpdate();
                
                if (affectedRows == 0) {
                    throw new SQLException("Creating plan failed, no rows affected.");
                }
                
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        plan.setId(generatedKeys.getInt(1));
                    } else {
                        throw new SQLException("Creating plan failed, no ID obtained.");
                    }
                }
            }
            
            // If we have deliverables, add them
            if (plan.getDeliverables() != null && !plan.getDeliverables().isEmpty()) {
                PlanDeliverableDAO deliverableDAO = new PlanDeliverableDAO();
                final Connection finalConn = conn; // Make conn effectively final for lambda
                plan.getDeliverables().forEach(deliverable -> {
                    deliverable.setPlanId(plan.getId());
                    deliverableDAO.create(deliverable, finalConn);
                });
            }
            
            conn.commit();
            return plan;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error creating plan", e);
            if (conn != null) {
                DBConnectionUtil.rollback(conn);
            }
            return null;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    DBConnectionUtil.closeConnection(conn);
                } catch (SQLException e) {
                    LOGGER.log(Level.WARNING, "Error resetting auto-commit", e);
                }
            }
        }
    }
    
    // Get plan by ID
    public Plan findById(int id) {
        String sql = "SELECT p.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM plans p " +
                     "JOIN users u ON p.user_id = u.id " +
                     "WHERE p.id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Plan plan = mapResultSetToPlan(rs);
                    
                    // Load deliverables
                    PlanDeliverableDAO deliverableDAO = new PlanDeliverableDAO();
                    plan.setDeliverables(deliverableDAO.findByPlanId(id));
                    
                    // Load approvals
                    ApprovalDAO approvalDAO = new ApprovalDAO();
                    plan.setApprovals(approvalDAO.findByPlanId(id));
                    
                    return plan;
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding plan by ID: " + id, e);
        }
        
        return null;
    }
    
    // Get plans by user ID
    public List<Plan> findByUserId(int userId) {
        String sql = "SELECT p.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM plans p " +
                     "JOIN users u ON p.user_id = u.id " +
                     "WHERE p.user_id = ? " +
                     "ORDER BY p.date DESC";
        
        return findPlansByQuery(sql, userId);
    }
    
    // Get plans by date
    public List<Plan> findByDate(Date date) {
        String sql = "SELECT p.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM plans p " +
                     "JOIN users u ON p.user_id = u.id " +
                     "WHERE p.date = ? " +
                     "ORDER BY p.user_id";
        
        return findPlansByQuery(sql, date);
    }
    
    // Get plans by status
    public List<Plan> findByStatus(String status) {
        String sql = "SELECT p.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM plans p " +
                     "JOIN users u ON p.user_id = u.id " +
                     "WHERE p.status = ? " +
                     "ORDER BY p.date DESC";
        
        return findPlansByQuery(sql, status);
    }
    
    // Get plans by date range
    public List<Plan> findByDateRange(Date startDate, Date endDate) {
        String sql = "SELECT p.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM plans p " +
                     "JOIN users u ON p.user_id = u.id " +
                     "WHERE p.date BETWEEN ? AND ? " +
                     "ORDER BY p.date DESC, p.user_id";
        
        List<Plan> plans = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setDate(1, startDate);
            stmt.setDate(2, endDate);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Plan plan = mapResultSetToPlan(rs);
                    plans.add(plan);
                }
            }
            
            // Load deliverables for each plan
            PlanDeliverableDAO deliverableDAO = new PlanDeliverableDAO();
            for (Plan plan : plans) {
                plan.setDeliverables(deliverableDAO.findByPlanId(plan.getId()));
            }
            
            // Load approvals for each plan
            ApprovalDAO approvalDAO = new ApprovalDAO();
            for (Plan plan : plans) {
                plan.setApprovals(approvalDAO.findByPlanId(plan.getId()));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding plans by date range", e);
        }
        
        return plans;
    }
    
    // Get plans by user ID and date range
    public List<Plan> findByUserIdAndDateRange(int userId, Date startDate, Date endDate) {
        String sql = "SELECT p.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM plans p " +
                     "JOIN users u ON p.user_id = u.id " +
                     "WHERE p.user_id = ? AND p.date BETWEEN ? AND ? " +
                     "ORDER BY p.date DESC";
        
        List<Plan> plans = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            stmt.setDate(2, startDate);
            stmt.setDate(3, endDate);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Plan plan = mapResultSetToPlan(rs);
                    plans.add(plan);
                }
            }
            
            // Load deliverables for each plan
            PlanDeliverableDAO deliverableDAO = new PlanDeliverableDAO();
            for (Plan plan : plans) {
                plan.setDeliverables(deliverableDAO.findByPlanId(plan.getId()));
            }
            
            // Load approvals for each plan
            ApprovalDAO approvalDAO = new ApprovalDAO();
            for (Plan plan : plans) {
                plan.setApprovals(approvalDAO.findByPlanId(plan.getId()));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding plans by user ID and date range", e);
        }
        
        return plans;
    }
    
    // Get all plans
    public List<Plan> findAll() {
        String sql = "SELECT p.*, u.name as user_name, u.email as user_email, u.role as user_role " +
                     "FROM plans p " +
                     "JOIN users u ON p.user_id = u.id " +
                     "ORDER BY p.date DESC";
        
        List<Plan> plans = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Plan plan = mapResultSetToPlan(rs);
                plans.add(plan);
            }
            
            // Load deliverables for each plan
            PlanDeliverableDAO deliverableDAO = new PlanDeliverableDAO();
            for (Plan plan : plans) {
                plan.setDeliverables(deliverableDAO.findByPlanId(plan.getId()));
            }
            
            // Load approvals for each plan
            ApprovalDAO approvalDAO = new ApprovalDAO();
            for (Plan plan : plans) {
                plan.setApprovals(approvalDAO.findByPlanId(plan.getId()));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding all plans", e);
        }
        
        return plans;
    }
    
    // Delete all plans
    public boolean deleteAll() {
        String sql = "DELETE FROM plans";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            
            int affectedRows = stmt.executeUpdate(sql);
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting all plans", e);
            return false;
        }
    }
    
    // Update plan
    public boolean update(Plan plan) {
        String sql = "UPDATE plans SET user_id = ?, date = ?, status = ? WHERE id = ?";
        Connection conn = null;
        
        try {
            conn = DBConnectionUtil.getConnection();
            conn.setAutoCommit(false);
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, plan.getUserId());
                stmt.setDate(2, plan.getDate());
                stmt.setString(3, plan.getStatus());
                stmt.setInt(4, plan.getId());
                
                int affectedRows = stmt.executeUpdate();
                
                if (affectedRows == 0) {
                    throw new SQLException("Updating plan failed, no rows affected.");
                }
            }
            
            // Update deliverables if they exist
            if (plan.getDeliverables() != null && !plan.getDeliverables().isEmpty()) {
                PlanDeliverableDAO deliverableDAO = new PlanDeliverableDAO();
                final Connection finalConn = conn; // Make conn effectively final for lambda
                plan.getDeliverables().forEach(deliverable -> {
                    if (deliverable.getId() > 0) {
                        deliverableDAO.update(deliverable, finalConn);
                    } else {
                        deliverable.setPlanId(plan.getId());
                        deliverableDAO.create(deliverable, finalConn);
                    }
                });
            }
            
            conn.commit();
            return true;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error updating plan: " + plan.getId(), e);
            if (conn != null) {
                DBConnectionUtil.rollback(conn);
            }
            return false;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    DBConnectionUtil.closeConnection(conn);
                } catch (SQLException e) {
                    LOGGER.log(Level.WARNING, "Error resetting auto-commit", e);
                }
            }
        }
    }
    
    // Delete plan
    public boolean delete(int id) {
        String sql = "DELETE FROM plans WHERE id = ?";
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting plan: " + id, e);
            return false;
        }
    }
    
    // Helper method to find plans by a parameterized query
    private List<Plan> findPlansByQuery(String sql, Object param) {
        List<Plan> plans = new ArrayList<>();
        
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            if (param instanceof Integer) {
                stmt.setInt(1, (Integer) param);
            } else if (param instanceof Date) {
                stmt.setDate(1, (Date) param);
            } else if (param instanceof String) {
                stmt.setString(1, (String) param);
            }
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Plan plan = mapResultSetToPlan(rs);
                    plans.add(plan);
                }
            }
            
            // Load deliverables for each plan
            PlanDeliverableDAO deliverableDAO = new PlanDeliverableDAO();
            for (Plan plan : plans) {
                plan.setDeliverables(deliverableDAO.findByPlanId(plan.getId()));
            }
            
            // Load approvals for each plan
            ApprovalDAO approvalDAO = new ApprovalDAO();
            for (Plan plan : plans) {
                plan.setApprovals(approvalDAO.findByPlanId(plan.getId()));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error executing query: " + sql, e);
        }
        
        return plans;
    }
    
    // Helper method to map ResultSet to Plan object
    private Plan mapResultSetToPlan(ResultSet rs) throws SQLException {
        Plan plan = new Plan();
        plan.setId(rs.getInt("id"));
        plan.setUserId(rs.getInt("user_id"));
        plan.setDate(rs.getDate("date"));
        plan.setStatus(rs.getString("status"));
        plan.setCreatedAt(rs.getTimestamp("created_at"));
        plan.setUpdatedAt(rs.getTimestamp("updated_at"));
        
        // Create and set user
        User user = new User();
        user.setId(rs.getInt("user_id"));
        user.setName(rs.getString("user_name"));
        user.setEmail(rs.getString("user_email"));
        user.setRole(rs.getString("user_role"));
        
        plan.setUser(user);
        return plan;
    }
}
